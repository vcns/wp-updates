<?php
/**
 * Plugin Name:       VCNS Security Automation Manager
 * Plugin URI:        https://github.com/vcns/security-automation-manager
 * Update URI:        https://github.com/vcns/security-automation-manager
 * Description:       Self-learning security headers, built-in attack detection and rate limiting, file-integrity monitoring, and free TLS certificates. No paywall.
 * Version:           2.11.6
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            VCNS Tech Ltd
 * Author URI:        https://vcns.tech
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vcns-security-automation-manager
 * Domain Path:       /languages
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Core constants ────────────────────────────────────────────────────────────
define( 'WP_SAM_VERSION', '2.11.6' );

/**
 * Schema version. Increment whenever a database schema change is made.
 * maybe_upgrade_db() in Plugin compares this against the stored value and
 * calls Activator::activate() (which runs dbDelta) when they differ.
 *
 * v1 -- initial schema (7 tables)
 * v2 -- adds override_expires_at and override_owner to csp_policy_profiles
 * v3 -- adds sample column to csp_violation_reports (R7: report-sample support)
 * v4 -- adds csp_audit_log append-only table (R10: immutable audit log)
 * v5 -- adds policy change proposal metadata and decision/suppression ledger
 * v6 -- adds violation first/last reported roll-up timestamps and unique fingerprint upsert support
 * v7 -- adds decision provenance, policy version snapshots, and deterministic rule evaluations
 * v8 -- adds last_seen_at and source_host indexes to csp_source_inventory, and an
 *        occurrence_count index to csp_violation_reports, for the sortable/filterable
 *        dashboard tables
 * v9 -- renames shared/generic tables (csp_scan_logs, csp_entitlements,
 *        csp_processed_events, csp_audit_log, csp_policy_change_decisions,
 *        csp_policy_versions, csp_decision_rule_evaluations) to a sam_ prefix
 *        ahead of multi-pillar support; CSP-owned tables (csp_policy_profiles,
 *        csp_source_inventory, csp_hash_inventory, csp_violation_reports) are
 *        unchanged. Existing installs are migrated via RENAME TABLE, not
 *        create+copy+drop, so no data is lost.
 * v10 -- adds sam_pillar_profiles, a shared per-surface profile table for
 *        header pillars simple enough not to need CSP's directive/override/
 *        strict-dynamic shape (X-Frame-Options, X-Content-Type-Options,
 *        Referrer-Policy, and future pillars). Starts empty; nothing reads
 *        or writes it until those pillars ship.
 * v11 -- adds sam_dependency_inventory (third-party script/stylesheet origin
 *        governance).
 * v12 -- migrates fenced-frame-src out of any already-seeded profile's stored
 *        directives JSON (removed from the default set as an experimental,
 *        non-standard directive commonly flagged by CSP linters); adds
 *        trusted_types to csp_policy_profiles for the per-surface Trusted
 *        Types toggle.
 * v13 -- adds sam_pillar_violation_reports, a generic Reporting API violation
 *        store for pillars other than CSP (currently Cross-Origin-Opener-Policy
 *        and Cross-Origin-Embedder-Policy, the only two with a browser-native
 *        report-only + reporting delivery mechanism). See Pillar_Violation_Store.
 * v14 -- adds blocked_host to csp_violation_reports and switches violation
 *        dedup from exact-URL to host granularity (see
 *        Violation_Reporter::extract_blocked_host()) -- a CDN/font-provider
 *        serving each request from a distinct, content-hashed filename under
 *        the same host no longer gets a permanent row per file. Existing
 *        rows are merged accordingly on upgrade.
 * v15 -- widens sam_pillar_profiles.pillar from varchar(32) to varchar(48).
 *        X_Permitted_Cross_Domain_Policies_Builder::PILLAR_KEY
 *        ('x-permitted-cross-domain-policies') is 33 characters, one over
 *        the old column length, so every toggle for that one pillar either
 *        failed outright (strict SQL mode) or was silently truncated to a
 *        different, unreadable key (non-strict mode) -- the Overview table
 *        always showed it as "Off" regardless of what was saved.
 * v16 -- adds sam_internal_asset_inventory, a first-party (theme/plugin/core)
 *        script and stylesheet integrity inventory. See
 *        Internal_Script_Integrity_Builder.
 * v17 -- default_directives() no longer includes data: in img-src (data: URIs
 *        can't execute active content, so the risk was always low, but a site
 *        that doesn't need inline/base64 images gets a tighter default).
 *        Migrates any existing profile whose img-src still exactly matches
 *        the old default; a profile an administrator has already customised
 *        is left untouched. See migrate_tighten_img_src_default().
 * v18 -- seeds a vetted, enabled configuration for X-Frame-Options,
 *        X-Content-Type-Options, Referrer-Policy, Permissions-Policy,
 *        Reverse Tabnabbing, Cross-Origin-Resource-Policy,
 *        Cross-Origin-Opener-Policy, Cross-Origin-Embedder-Policy, and
 *        X-Permitted-Cross-Domain-Policies on every surface that doesn't
 *        already have a row, so a fresh install ships with this hardening
 *        active by default. HSTS is deliberately excluded -- see
 *        seed_default_pillar_profiles(). Also changes the default CSP
 *        automation-approval mode from manual to automatic (high approvals
 *        only); this only affects who approves a proposed CSP source, not
 *        CSP enforcement, which still requires a deliberate admin
 *        promotion through the existing learning window and promotion
 *        gate regardless of automation mode.
 * v19 -- adds last_seen_url to sam_dependency_inventory: the most recently
 *        observed full URL (path and query included) for a governed
 *        third-party origin. The dedup key stays origin-only (scheme+host),
 *        but the "Suggest" SRI hash helper needs an exact file URL to fetch
 *        and hash, which the origin alone can't provide.
 * v20 -- adds bypass_img_src_data, bypass_font_src_data tinyint columns to
 *        csp_policy_profiles for the Profiles tab's "Bypass Best Practices"
 *        toggles: a small, hardcoded, per-surface opt-in for specific
 *        directive+token relaxations (data: URIs in img-src/font-src) that
 *        are safe despite being high-risk for automation. See
 *        Policy_Builder::BYPASS_CATALOG.
 * v21 -- adds sam_certificates for ACME (Let's Encrypt) certificate
 *        automation: issued certificate metadata, sealed private key, and
 *        expiry tracking for the renewal scheduler. See
 *        Certificates\Certificate_Store.
 * v22 -- adds bypass_style_attr_unsafe_hashes tinyint column to
 *        csp_policy_profiles, and moves 'unsafe-hashes' emission on
 *        style-src-attr out of automatic (whenever a hash exists) and into
 *        BYPASS_CATALOG as its own explicit, labelled opt-in -- a scanner
 *        will flag this keyword, so enabling it must be a conscious admin
 *        decision, not something the plugin decided on its own.
 * v23 -- adds sam_migration_snapshots: a bounded (last 5) history of
 *        configuration-state table contents captured immediately before
 *        each forward schema migration, so a migration whose data effects
 *        turn out to be unwanted can be undone without reinstalling old
 *        plugin code. See Rollback_Guard.
 * v24 -- default_directives() now seeds media-src as ['self'] instead of
 *        ['none'] -- same-origin video/audio can't execute script, and
 *        blocking it by default broke WordPress core's own native
 *        Video/Audio blocks (self-hosted media) out of the box for no
 *        corresponding security benefit; every other same-origin-safe
 *        directive (img-src, font-src, connect-src, form-action) already
 *        defaulted to 'self'. Migrates any existing profile whose
 *        media-src still exactly matches the old ['none'] default; a
 *        profile an administrator has already customised is left
 *        untouched. See migrate_loosen_media_src_default().
 * v25 -- adds bypass_flags (JSON array of enabled Policy_Builder::
 *        BYPASS_CATALOG keys) to csp_policy_profiles, replacing the three
 *        legacy per-entry tinyint columns (bypass_img_src_data,
 *        bypass_font_src_data, bypass_style_attr_unsafe_hashes) -- a
 *        single column rather than one per catalog entry, so the "Bypass
 *        Best Practices" catalog can keep growing without a schema
 *        migration for every addition. The catalog itself grows from 3 to
 *        9 entries in this same release. Legacy columns are converted once
 *        via migrate_consolidate_bypass_flags_into_json() and left in
 *        place afterwards (dbDelta() cannot drop columns) but are no
 *        longer read by anything.
 * v26 -- adds sam_request_events for the Request Observation Framework
 *        (Layer 3: Continuous Intelligence) -- ships empty in this release;
 *        no detector is registered yet, so nothing writes to it. See
 *        Intelligence\Event_Store.
 * v27 -- adds sam_scanner_vendors and sam_scanner_identities (Phase 3D:
 *        Identity and Scanner Intelligence). sam_scanner_vendors is seeded
 *        with two built-in, FCrDNS-verified search crawlers (Googlebot,
 *        Bingbot); administrators can add their own commercial scanner
 *        vendors. sam_scanner_identities records every resolved request
 *        identity, with automatic recognition state kept structurally
 *        separate from administrator authorisation decisions -- see
 *        Intelligence\Scanner_Identity_Store.
 * v28 -- adds sam_traffic_policies, sam_ip_rules, and sam_traffic_blocks
 *        (Phase 3E: Traffic Controls) -- this plugin's first schema
 *        supporting actively rejecting a request rather than only adding
 *        response headers. Every surface seeds in 'observe' mode; nothing
 *        blocks until an administrator explicitly promotes a surface to
 *        'enforce'. See Intelligence\Traffic_Guard.
 * v29 -- adds sam_security_baselines, sam_drift_records, and sam_change_log
 *        (Phase 3F: Baseline and Drift). An administrator-approved snapshot
 *        of locally-known configuration state, diffed on each scan against
 *        current state; differences become drift records an administrator
 *        can review. Ships with no baseline approved -- nothing to diff
 *        against until an administrator explicitly captures one. See
 *        Intelligence\Baseline_State_Builder and Intelligence\Drift_Scanner.
 * v30 -- adds sam_campaigns, sam_honeypaths, sam_change_windows, and an
 *        indexed `ip` column on sam_request_events (Phase 3J: Advanced
 *        Optional Intelligence -- campaign detection, deception/honey
 *        paths, integrity monitoring, change attribution timeline, and
 *        security change windows). Every new capability observes/records
 *        only by default; nothing blocks or exposes decoy content without
 *        an explicit administrator action. See Intelligence\Campaign_
 *        Detector, Intelligence\Detectors\Honeypath_Detector, and
 *        Intelligence\Change_Window_Store.
 * v31 -- adds sam_tor_exit_nodes (Phase 4A: Traffic Intelligence Data
 *        Sourcing -- Tor Awareness, .roadmap/phase4_plan.md). Holds the
 *        Tor Project's own public bulk exit-node list, refreshed daily;
 *        built first among Geo-IP/ASN/Tor because it needs no account or
 *        licensing decision. Observation only -- Tor identity never
 *        implies malicious intent and nothing blocks by default. See
 *        Intelligence\Tor_Exit_List_Store and
 *        Intelligence\Network_Intelligence_Resolver.
 * v32 -- adds sam_asn_cache (Phase 4A, second increment -- ASN Controls,
 *        .roadmap/phase4_plan.md, .roadmap/phase3_early_plan.md §13.5).
 *        Caches Team Cymru's free, unauthenticated per-IP ASN DNS lookup
 *        (no account or licensing decision needed) so its cost is paid
 *        once per IP, not on every request. Observation only. See
 *        Intelligence\Asn_Lookup_Store.
 * v33 -- adds sam_geoip_cache (Phase 4A, third increment -- Geo-IP
 *        Controls, .roadmap/phase3_early_plan.md §13.4). Entirely opt-in
 *        and bring-your-own-credentials -- disabled until an
 *        administrator enters their own IPinfo API token, sealed via
 *        Credential_Vault, never a shared VCNS credential. MaxMind
 *        support deliberately deferred (its free tier is a downloaded
 *        binary database, not a live API -- see Intelligence\Geo_Ip_
 *        Store's own docblock). Observation only, and Geo-IP blocking is
 *        never enabled by default, per the roadmap's explicit requirement.
 * v34 -- adds sam_detector_policies (Phase 4B, first increment -- the
 *        control-action framework, .roadmap/phase4_plan.md, .roadmap/
 *        phase3_early_plan.md §11's shared detector metadata contract).
 *        Holds an optional per-detector admin override: enabled/disabled,
 *        and which control action ('observe' or 'enforce') a match should
 *        trigger. A missing row means "enabled, detector's own default" --
 *        every detector shipped before this stays behaviourally identical
 *        until an administrator explicitly changes something. 'enforce'
 *        feeds the exact same Traffic_Block_Store progressive-response
 *        ladder rate-limit and login-brute-force violations already use --
 *        no new blocking path. See Intelligence\Detector_Policy_Store and
 *        Intelligence\Detector_Engine.
 * v35 -- no new table -- bumped purely to re-run Activator::seed_default_
 *        scanner_vendors() on every already-upgraded site (Phase 4C, first
 *        increment -- AI-crawler identity seeding, .roadmap/phase4_plan.md,
 *        .roadmap/phase3_early_plan.md §10). Adds GPTBot, ClaudeBot, CCBot,
 *        and PerplexityBot to the built-in sam_scanner_vendors catalogue,
 *        the same idempotent, missing-row-only seed Googlebot/Bingbot
 *        already use. Without this bump, maybe_upgrade_db() would never
 *        call Activator::activate() again on a site already at v34, and
 *        the new vendor rows would only appear on a fresh install.
 * v36 -- adds recent_paths to sam_scanner_identities (Phase 4C -- URI-
 *        pattern signal, .roadmap/phase4_plan.md, .roadmap/phase3_early_
 *        plan.md §10). Bounded JSON array (Scanner_Identity_Store::
 *        MAX_RECENT_PATHS, oldest dropped first) of an identity's recent
 *        request paths, read by the new Uri_Pattern_Analyzer to recognise
 *        sequential/enumerating access (e.g. /product/101, /product/102,
 *        /product/103) as its own bot-classification signal, and to
 *        answer §10's "log the fact they're hitting the endpoint" plainly
 *        on the Identities admin view. See Intelligence\Scanner_Identity_
 *        Store and Intelligence\Uri_Pattern_Analyzer.
 *   v37: adds sam_custom_detector_rules (Phase 4C extension: admin-authored,
 *        fail2ban-style custom regex detection rules). One row per rule;
 *        Plugin::register_detectors() constructs and registers a Custom_
 *        Rule_Detector per row on every request, flowing through the exact
 *        same Detector_Registry/Detector_Policy_Store/Detector_Engine
 *        pipeline every built-in §11 family already uses. See Intelligence\
 *        Custom_Rule_Store and Intelligence\Detectors\Custom_Rule_Detector.
 *   v38: adds sam_network_rules (Phase 4A extension, user-requested: the
 *        "traffic control filtering" half of Geo-IP/ASN/Tor awareness that
 *        Phase 4A itself shipped as evidence-only). Administrator-entered
 *        ASN/country block-list entries, checked by Traffic_Guard alongside
 *        sam_ip_rules. Tor exit-node filtering needed no new table -- it
 *        shipped as a new detector (Tor_Exit_Detector) instead, since a
 *        local, already-refreshed exit-node table is cheap to check on
 *        every request. ASN/country resolution stays lazy (no live DNS/
 *        API lookup) unless at least one sam_network_rules row exists --
 *        see Intelligence\Traffic_Guard's own docblock.
 *   v39: no new table -- flips an existing install's default wp_sam_
 *        reporting_transport from 'report-uri' to 'both' (user-reported
 *        production incident: an unthrottled violation storm from
 *        report-uri's one-immediate-request-per-violation behaviour
 *        exhausted a customer's PHP-FPM worker pool). 'both' still emits
 *        report-uri as a fallback for browsers without Reporting API
 *        support; browsers that do support it batch violation delivery via
 *        report-to instead. See Activator::migrate_default_reporting_
 *        transport_to_both() for why this is a one-time migration guarded
 *        by its own completion marker rather than re-applied on every
 *        future activation.
 *   v40: adds sam_exceptions -- controlled, time-bound weakening of a
 *        control/surface, with a required business justification, owner,
 *        risk classification, and expiry date (GitHub issue #177). See
 *        Intelligence\Exception_Store.
 *   v41: no new table -- bumped purely to re-run Activator::seed_default_
 *        scanner_vendors() on every already-upgraded site (Phase 4C,
 *        second increment). Adds 10 more built-in search/AI crawlers to
 *        the sam_scanner_vendors catalogue: YandexBot, Baiduspider,
 *        DuckDuckBot, Applebot, Sogou web spider, SeznamBot,
 *        OAI-SearchBot, Amazonbot, DuckAssistBot, and Meta-ExternalAgent.
 *        See seed_default_scanner_vendors()'s own docblock for sourcing.
 *   v42: adds asn, asn_org, geo_country, geo_region, geo_city to
 *        sam_scanner_identities (Phase 4A carried-forward item -- ASN was
 *        resolved and recorded in Event_Store evidence per-request but
 *        never merged onto the identity record itself). Populated the same
 *        way Event_Store's evidence already is: Network_Intelligence_
 *        Resolver::resolve() only runs when at least one detector already
 *        produced a finding this request (Request_Observer's existing
 *        §33 performance gate, unchanged) -- so an identity that never
 *        triggers a detector keeps these columns null, same zero-added-
 *        cost guarantee as before, and a repeat offender's row fills in
 *        opportunistically as soon as any of its requests does trigger a
 *        finding. See Intelligence\Scanner_Identity_Store::record() and
 *        Intelligence\Request_Observer.
 *   v43: adds recent_seen_at to sam_scanner_identities (Phase 4C carried-
 *        forward item -- the "timing" signal §10's own signal list names,
 *        never built). Bounded JSON array (Scanner_Identity_Store::
 *        MAX_RECENT_PATHS, oldest dropped first) of this identity's recent
 *        request timestamps, appended in lockstep with the existing
 *        recent_paths on every record() call. Read by the new Request_
 *        Timing_Analyzer, wired into Bot_Classifier as a third signal for
 *        an unrecognised source (alongside URI-pattern enumeration and
 *        rate escalation): a new 'scripted_timing' classification state
 *        when the last several requests arrived at a suspiciously uniform
 *        interval, distinct from enumeration (which is about *what* a
 *        source requests; this is about *when*).
 *   v44: adds recent_errors to sam_scanner_identities (Phase 4C carried-
 *        forward item -- the "repeated errors" signal §10's own list
 *        names, the second and last of the two). Bounded JSON array of
 *        0/1 ints, appended in lockstep with recent_paths/recent_seen_at,
 *        recording whether each request's eventual HTTP response was
 *        >= 400. Required moving Scanner_Identity_Store::record() itself
 *        from Request_Observer's main observe() flow to a new 'shutdown'
 *        hook (flush_identity_write()) -- the eventual response status
 *        isn't known yet at send_headers time, since WordPress hasn't run
 *        query_posts()/handle_404() yet at that point in WP::main().
 *        Identity *resolution* (Identity_Resolver::resolve()) stays where
 *        it was, unchanged -- only the *write* is deferred. Read by the
 *        new Repeated_Error_Analyzer, wired into Bot_Classifier as a
 *        fourth signal for an unrecognised source: a new
 *        'error_probing_scanner' classification state when a
 *        disproportionate share of a source's recent requests were
 *        4xx/5xx -- the classic signature of a scanner probing for paths
 *        that don't exist or aren't allowed.
 *   v45: adds sam_recommendation_dismissals (Phase 4F, Recommendations
 *        Engine -- .roadmap/phase3_early_plan.md §22, Foundation increment).
 *        The only new table this feature needs: one row per administrator
 *        decision not to act on a live recommendation yet, with a required
 *        reason. Recommendation content itself is never persisted -- it is
 *        always recomputed from existing evidence on each admin page load.
 *        See Intelligence\Recommendation_Engine, Intelligence\
 *        Recommendation_Registry, Intelligence\Recommendation_Dismissal_Store.
 *   v46: no new table -- bumped purely to re-run activate()'s new generic
 *        wp_sam_extension_migrations hook on every already-upgraded site.
 *        includes/extensions/fully-automatic-mode.php listens on it to
 *        remove any previously-stored Stripe secret/price/webhook option
 *        values now that it no longer has a direct-Stripe checkout path
 *        (docs/threat-model.md "Stripe secret storage" finding; docs/
 *        sam-portal-requirements-spec.md §21.2). That cleanup deliberately
 *        lives in the extension, not in Activator itself -- a core
 *        migration referencing those exact option-name strings would put
 *        them in a file every channel ships, defeating .github/scripts/
 *        verify-wporg-package.sh's whole purpose. Only ever mattered on a
 *        private/commercial build -- neither public release channel has
 *        ever shipped a working checkout path.
 */
define( 'WP_SAM_DB_VERSION', '47' );

define( 'WP_SAM_FILE', __FILE__ );
define( 'WP_SAM_DIR', plugin_dir_path( __FILE__ ) );
define( 'WP_SAM_URL', plugin_dir_url( __FILE__ ) );
define( 'WP_SAM_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

$wp_sam_build_channel = WP_SAM_DIR . 'includes/build-channel.php';
if ( is_readable( $wp_sam_build_channel ) ) {
	require $wp_sam_build_channel;
}
unset( $wp_sam_build_channel );

if ( ! defined( 'WP_SAM_DISTRIBUTION_CHANNEL' ) ) {
	define( 'WP_SAM_DISTRIBUTION_CHANNEL', 'wordpress-org' );
}

if ( ! defined( 'WP_SAM_UPDATE_MANIFEST_URL' ) ) {
	define( 'WP_SAM_UPDATE_MANIFEST_URL', 'https://vcns.github.io/wp-updates/security-automation-manager/update.json' );
}

// ── PSR-4 autoloader ──────────────────────────────────────────────────────────
spl_autoload_register(
	static function ( string $class_name ): void {
		$prefix = 'WP_SAM\\';
		if ( strncmp( $prefix, $class_name, strlen( $prefix ) ) !== 0 ) {
			return;
		}
		$relative = substr( $class_name, strlen( $prefix ) );
		$parts    = explode( '\\', $relative );
		$filename = 'class-' . strtolower( str_replace( '_', '-', (string) array_pop( $parts ) ) ) . '.php';
		$subdir   = ! empty( $parts ) ? strtolower( implode( '/', $parts ) ) . '/' : '';

		// Public includes/ directory.
		$file = WP_SAM_DIR . 'includes/' . $subdir . $filename;
		if ( is_readable( $file ) ) {
			require $file;
			return;
		}

		// offline/ directory: proprietary modules never committed to the repository.
		$file = WP_SAM_DIR . 'offline/' . $subdir . $filename;
		if ( is_readable( $file ) ) {
			require $file;
		}
	}
);

// ── Optional extensions ───────────────────────────────────────────────────────
// Files here self-register via WordPress hooks (see class-plugin.php's
// wp_sam_register_automation_modes action) -- this file has no knowledge of
// what, if anything, exists in this directory, and never references any
// extension's class or file name. The WordPress.org-channel build removes
// this directory entirely (see .github/workflows/wporg-deploy.yml and
// release-package.yml); on that channel this glob returns nothing and the
// loop body never runs.
$wp_sam_extension_files = glob( WP_SAM_DIR . 'includes/extensions/*.php' );
foreach ( false !== $wp_sam_extension_files ? $wp_sam_extension_files : array() as $wp_sam_extension_file ) {
	require $wp_sam_extension_file;
}
unset( $wp_sam_extension_files, $wp_sam_extension_file );

// ── Lifecycle hooks ───────────────────────────────────────────────────────────
register_activation_hook( __FILE__, array( 'WP_SAM\\Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WP_SAM\\Deactivator', 'deactivate' ) );

// ── Bootstrap ─────────────────────────────────────────────────────────────────
add_action(
	'plugins_loaded',
	static function (): void {
		WP_SAM\Plugin::instance()->init();

		if (
			'github' === WP_SAM_DISTRIBUTION_CHANNEL
			&& ( is_admin() || wp_doing_cron() )
			&& is_readable( WP_SAM_DIR . 'includes/modules/class-github-update-checker.php' )
		) {
			( new WP_SAM\Modules\Github_Update_Checker() )->register();
		}
	}
);
