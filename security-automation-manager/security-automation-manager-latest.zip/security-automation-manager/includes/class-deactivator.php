<?php
/**
 * Fired during plugin deactivation.
 * Removes scheduled cron events; leaves data intact (use uninstall.php to purge).
 */

declare( strict_types=1 );

namespace WP_SAM;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Deactivator {

	/**
	 * Plugin deactivation entry point: clears the scheduled scan and certificate events.
	 *
	 * @return void
	 */
	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'wp_sam_daily_scan' );
		wp_clear_scheduled_hook( 'wp_sam_cert_issue' );
		wp_clear_scheduled_hook( 'wp_sam_cert_renewal_check' );
		wp_clear_scheduled_hook( 'wp_sam_dependency_hash_check' );
		wp_clear_scheduled_hook( 'wp_sam_page_cache_purge_check' );
		wp_clear_scheduled_hook( 'wp_sam_delivered_policy_check' );
	}
}
