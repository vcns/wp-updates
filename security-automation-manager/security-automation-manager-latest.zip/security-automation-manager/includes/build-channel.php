<?php
/**
 * Generated build-channel marker for the GitHub release ZIP.
 */

declare( strict_types=1 );

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

if ( ! defined( 'WP_SAM_DISTRIBUTION_CHANNEL' ) ) {
  define( 'WP_SAM_DISTRIBUTION_CHANNEL', 'github' );
}
