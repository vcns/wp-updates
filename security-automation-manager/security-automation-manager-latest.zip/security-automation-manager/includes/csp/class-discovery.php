<?php
/**
 * Runtime and crawl-based source discovery.
 *
 * Implements §4.6 of the directive:
 *   - Crawls pages using the WordPress HTTP API.
 *   - Parses HTML response for external script, style, img, font, connect,
 *     frame, media, and manifest sources.
 *   - Classifies each discovered URL into the correct CSP directive.
 *   - Proposes new sources via Policy_Change_Manager with approval_state='pending'.
 *   - Marks sources not seen in current crawl as candidates for removal.
 *
 * Coverage notes:
 *   - connect-src (fetch, XHR, WebSocket) and worker-src are JavaScript
 *     runtime concerns. They cannot be reliably discovered from static HTML.
 *     These directives must be populated from CSP violation reports collected
 *     in report-only mode on a real browser session.
 *   - font-src is partially discoverable by fetching linked CSS and parsing
 *     @font-face src: declarations. This is implemented below.
 *   - media-src is discoverable from <audio> and <video> src attributes.
 *   - manifest-src is discoverable from <link rel="manifest"> href.
 *
 * Multi-surface crawl covers CSP's own surfaces (Csp_Surfaces::ALL) -- in
 * practice the frontend and login URLs, since admin has no anonymous crawl
 * target. The REST API is not crawled: it isn't a CSP surface, and a JSON
 * response has no subresources to discover anyway.
 */

declare( strict_types=1 );

namespace WP_SAM\CSP;

use WP_SAM\Intelligence\Same_Host_Fetcher;
use WP_SAM\Modules\Audit_Log;
use WP_SAM\Modules\Feature_Gate;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Discovery {

	private Audit_Log $audit;
	private Feature_Gate $gate;
	private Policy_Change_Manager $policy_changes;

	/**
	 * Constructor.
	 *
	 * @param Audit_Log                  $audit          Audit log.
	 * @param Feature_Gate               $gate           Feature gate.
	 * @param Policy_Change_Manager|null $policy_changes Policy change manager, a new one is created when omitted.
	 */
	public function __construct( Audit_Log $audit, Feature_Gate $gate, ?Policy_Change_Manager $policy_changes = null ) {
		$this->audit          = $audit;
		$this->gate           = $gate;
		$this->policy_changes = null !== $policy_changes ? $policy_changes : new Policy_Change_Manager( $audit );
	}

	// ── Public API ────────────────────────────────────────────────────────────

	/**
	 * Runs a full discovery pass across configured surfaces.
	 * Returns counts of added/updated records.
	 */
	public function run_scan(): array {
		$stats    = array(
			'sources_added'   => 0,
			'sources_updated' => 0,
		);
		$surfaces = array( 'frontend' );

		if ( $this->gate->is_allowed( 'multi_surface_scan' ) ) {
			$surfaces = Csp_Surfaces::ALL;
		}

		foreach ( $surfaces as $surface ) {
			$urls = $this->get_crawl_urls( $surface );
			foreach ( $urls as $url ) {
				$result                    = $this->crawl_url( $url, $surface );
				$stats['sources_added']   += $result['added'];
				$stats['sources_updated'] += $result['updated'];
			}
		}

		return $stats;
	}

	/**
	 * Discovers sources from a single URL and stores them.
	 *
	 * Uses Same_Host_Fetcher so a redirect away from this site (e.g. an IP
	 * allow-list sending unrecognised addresses elsewhere) is reported --
	 * without saying where it pointed -- rather than silently crawled as if
	 * it were this site. A 401/403 is logged at info
	 * only: it is almost always a firewall or login protection refusing an
	 * anonymous request, not something wrong with this plugin or the site.
	 */
	public function crawl_url( string $url, string $surface ): array {
		$response = ( new Same_Host_Fetcher() )->get(
			$url,
			array(
				'timeout'    => 20,
				'user-agent' => 'WP-CSP-Discovery/' . WP_SAM_VERSION,
				'sslverify'  => true,
			)
		);

		if ( is_wp_error( $response ) && 'wp_sam_offsite_redirect' === $response->get_error_code() ) {
			$data = (array) $response->get_error_data();
			$code = (int) ( $data['code'] ?? 0 );
			$this->audit->log( 'discovery', 'crawl_redirected_offsite', "{$url} redirected away from this site (HTTP {$code}), so this page was not crawled.", 'warning' );
			return array(
				'added'   => 0,
				'updated' => 0,
			);
		}

		if ( is_wp_error( $response ) ) {
			$this->audit->log( 'discovery', 'crawl_failed', "Failed to fetch {$url}: " . $response->get_error_message(), 'warning' );
			return array(
				'added'   => 0,
				'updated' => 0,
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 401 === $code || 403 === $code ) {
			$this->audit->log( 'discovery', 'crawl_blocked', "HTTP {$code} for {$url}: the request was refused, likely by a firewall or login protection, so this page was not crawled.", 'info' );
			return array(
				'added'   => 0,
				'updated' => 0,
			);
		}
		if ( $code < 200 || $code >= 400 ) {
			$this->audit->log( 'discovery', 'crawl_http_error', "HTTP {$code} for {$url}.", 'warning' );
			return array(
				'added'   => 0,
				'updated' => 0,
			);
		}

		$html    = wp_remote_retrieve_body( $response );
		$sources = $this->parse_html_sources( $html, $url );

		return $this->upsert_sources( $sources, $surface );
	}

	// ── HTML parsing ──────────────────────────────────────────────────────────

	/**
	 * Extracts external source URLs from an HTML document.
	 *
	 * Directives covered by static HTML parsing:
	 *   script-src-elem  -- <script src>
	 *   style-src-elem   -- <link rel="stylesheet">
	 *   img-src          -- <img src>
	 *   frame-src        -- <iframe src>
	 *   form-action      -- <form action>
	 *   media-src        -- <audio src>, <video src>, <source src> inside media elements
	 *   manifest-src     -- <link rel="manifest">
	 *   font-src         -- @font-face src in linked CSS (fetched separately)
	 *
	 * Directives NOT covered by static HTML (violation-report-driven only):
	 *   connect-src      -- fetch(), XMLHttpRequest, WebSocket, EventSource
	 *   worker-src       -- new Worker(), new SharedWorker()
	 *
	 * Returns array of [ 'directive' => string, 'uri' => string, 'host' => string, 'scheme' => string ].
	 */
	public function parse_html_sources( string $html, string $base_url ): array {
		if ( empty( trim( $html ) ) ) {
			return array();
		}

		$doc = new \DOMDocument();
		// Suppress malformed HTML warnings; we do best-effort parsing.
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		@$doc->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR );

		$found = array();

		// Scripts → script-src-elem
		foreach ( $doc->getElementsByTagName( 'script' ) as $el ) {
			$src = trim( $el->getAttribute( 'src' ) );
			if ( $src && ! $this->is_inline_data( $src ) ) {
				$found[] = $this->classify_url( $src, 'script-src-elem', $base_url );
			}
		}

		// Collect stylesheet hrefs for separate CSS parsing and classify here.
		$stylesheet_urls = array();
		foreach ( $doc->getElementsByTagName( 'link' ) as $el ) {
			$rel  = strtolower( trim( $el->getAttribute( 'rel' ) ) );
			$href = trim( $el->getAttribute( 'href' ) );

			if ( ! $href ) {
				continue;
			}

			if ( 'stylesheet' === $rel && ! $this->is_inline_data( $href ) ) {
				$found[]           = $this->classify_url( $href, 'style-src-elem', $base_url );
				$stylesheet_urls[] = $this->resolve_url( $href, $base_url );
			}

			// manifest-src
			if ( 'manifest' === $rel ) {
				$found[] = $this->classify_url( $href, 'manifest-src', $base_url );
			}
		}

		// Images → img-src
		foreach ( $doc->getElementsByTagName( 'img' ) as $el ) {
			$src = trim( $el->getAttribute( 'src' ) );
			if ( $src && ! $this->is_inline_data( $src ) ) {
				$found[] = $this->classify_url( $src, 'img-src', $base_url );
			}
		}

		// Iframes → frame-src
		foreach ( $doc->getElementsByTagName( 'iframe' ) as $el ) {
			$src = trim( $el->getAttribute( 'src' ) );
			if ( $src ) {
				$found[] = $this->classify_url( $src, 'frame-src', $base_url );
			}
		}

		// Forms → form-action
		foreach ( $doc->getElementsByTagName( 'form' ) as $el ) {
			$action = trim( $el->getAttribute( 'action' ) );
			if ( $action ) {
				$found[] = $this->classify_url( $action, 'form-action', $base_url );
			}
		}

		// Audio → media-src
		foreach ( $doc->getElementsByTagName( 'audio' ) as $el ) {
			$src = trim( $el->getAttribute( 'src' ) );
			if ( $src && ! $this->is_inline_data( $src ) ) {
				$found[] = $this->classify_url( $src, 'media-src', $base_url );
			}
		}

		// Video → media-src
		foreach ( $doc->getElementsByTagName( 'video' ) as $el ) {
			$src = trim( $el->getAttribute( 'src' ) );
			if ( $src && ! $this->is_inline_data( $src ) ) {
				$found[] = $this->classify_url( $src, 'media-src', $base_url );
			}
		}

		// <source> inside <audio>/<video> → media-src
		foreach ( $doc->getElementsByTagName( 'source' ) as $el ) {
			$src = trim( $el->getAttribute( 'src' ) );
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$parent = $el->parentNode;
			if ( $src && ! $this->is_inline_data( $src ) && $parent ) {
				// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
				$parent_tag = strtolower( $parent->nodeName );
				if ( in_array( $parent_tag, array( 'audio', 'video' ), true ) ) {
					$found[] = $this->classify_url( $src, 'media-src', $base_url );
				}
			}
		}

		// font-src: parsed from linked CSS files (fetched separately).
		foreach ( array_filter( $stylesheet_urls ) as $css_url ) {
			$font_sources = $this->parse_stylesheet_sources( $css_url, $base_url );
			$found        = array_merge( $found, $font_sources );
		}

		// Filter out null entries and same-origin sources (already covered by 'self').
		$site_host = wp_parse_url( get_site_url(), PHP_URL_HOST );
		return array_filter( $found, static fn( $item ) => null !== $item && $item['host'] !== $site_host );
	}

	// ── CSS font-src parsing ──────────────────────────────────────────────────

	/**
	 * Fetches a CSS file and extracts @font-face src: URLs for font-src.
	 *
	 * Only external (non-self) font URLs are returned; same-origin fonts are
	 * filtered out by parse_html_sources() after this method returns.
	 *
	 * @param string $css_url   Absolute URL of the stylesheet to fetch.
	 * @param string $base_url  Base URL of the originating page (for resolution).
	 * @return array            Classified source entries.
	 */
	public function parse_stylesheet_sources( string $css_url, string $base_url ): array {
		if ( empty( $css_url ) || ! filter_var( $css_url, FILTER_VALIDATE_URL ) ) {
			return array();
		}

		$response = wp_remote_get(
			$css_url,
			array(
				'timeout'    => 10,
				'user-agent' => 'WP-CSP-Discovery/' . WP_SAM_VERSION,
				'sslverify'  => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			$this->audit->log( 'discovery', 'css_fetch_failed', "Failed to fetch CSS {$css_url}: " . $response->get_error_message(), 'warning' );
			return array();
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return array();
		}

		$css   = wp_remote_retrieve_body( $response );
		$found = array();

		// Match url() values inside @font-face blocks.
		// Pattern: @font-face { ... src: url('...') ... }
		if ( preg_match_all( '/@font-face\s*\{[^}]*src\s*:[^;}]+/i', $css, $face_blocks ) ) {
			foreach ( $face_blocks[0] as $block ) {
				if ( preg_match_all( '/url\(\s*[\'"]?([^\'"\)]+)[\'"]?\s*\)/i', $block, $url_matches ) ) {
					foreach ( $url_matches[1] as $font_url ) {
						$font_url = trim( $font_url );
						if ( $font_url && ! $this->is_inline_data( $font_url ) ) {
							$found[] = $this->classify_url( $font_url, 'font-src', $css_url );
						}
					}
				}
			}
		}

		return $found;
	}

	// ── DB upsert ─────────────────────────────────────────────────────────────

	/**
	 * Adds newly discovered sources to the inventory or refreshes the ones already known.
	 *
	 * @param array  $sources Discovered sources.
	 * @param string $surface Surface slug.
	 * @return array Counts of sources added and updated.
	 */
	private function upsert_sources( array $sources, string $surface ): array {
		$added   = 0;
		$updated = 0;

		foreach ( $sources as $src ) {
			if ( empty( $src['host'] ) ) {
				continue;
			}

			$result = $this->policy_changes->propose_source(
				$surface,
				$src,
				'discovery',
				'crawl',
				sprintf( 'Learned from discovery crawl. URL: %s', $src['uri'] )
			);

			if ( 'updated' === $result['status'] ) {
				++$updated;
			} elseif ( in_array( $result['status'], array( 'added', 'auto_approved' ), true ) ) {
				++$added;
			}
		}

		return array(
			'added'   => $added,
			'updated' => $updated,
		);
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	/**
	 * Resolves a URL found in a page and describes it as a policy source.
	 *
	 * @param string $raw_url   URL as found in the markup.
	 * @param string $directive CSP directive it was found under.
	 * @param string $base_url  Base URL used to resolve relative URLs.
	 * @return array|null Source details, or null when the URL cannot be used.
	 */
	private function classify_url( string $raw_url, string $directive, string $base_url ): ?array {
		$resolved = $this->resolve_url( $raw_url, $base_url );
		if ( null === $resolved ) {
			return null;
		}

		$parsed = wp_parse_url( $resolved );
		if ( empty( $parsed['host'] ) ) {
			return null;
		}

		return array(
			'directive' => $directive,
			'uri'       => esc_url_raw( $resolved ),
			'host'      => strtolower( $parsed['host'] ),
			'scheme'    => strtolower( isset( $parsed['scheme'] ) ? $parsed['scheme'] : 'https' ),
		);
	}

	/**
	 * Resolves a potentially relative URL against a base URL.
	 * Returns an absolute URL string or null if resolution fails.
	 *
	 * FIX: replaces the original inline resolution logic scattered inside
	 * classify_url() with a single dedicated method, and removes the
	 * esc_attr() call that was incorrectly HTML-encoding values destined
	 * for use in HTTP headers (esc_attr encodes & which is invalid in header values).
	 * sanitize_text_field() is used instead via esc_url_raw() in classify_url().
	 */
	private function resolve_url( string $raw_url, string $base_url ): ?string {
		if ( empty( $raw_url ) ) {
			return null;
		}

		if ( str_starts_with( $raw_url, '//' ) ) {
			return 'https:' . $raw_url;
		}

		if ( str_starts_with( $raw_url, 'http://' ) || str_starts_with( $raw_url, 'https://' ) ) {
			return $raw_url;
		}

		if ( str_starts_with( $raw_url, '/' ) ) {
			$parsed_base = wp_parse_url( $base_url );
			if ( empty( $parsed_base['host'] ) ) {
				return null;
			}
			return ( isset( $parsed_base['scheme'] ) ? $parsed_base['scheme'] : 'https' ) . '://' . $parsed_base['host'] . $raw_url;
		}

		// Relative path: resolve against base URL directory.
		$base_dir = substr( $base_url, 0, (int) strrpos( $base_url, '/' ) + 1 );
		return $base_dir . $raw_url;
	}

	/**
	 * Checks whether a source is inline data (a data: or blob: URI).
	 *
	 * @param string $src Source value.
	 * @return bool True for data: and blob: sources.
	 */
	private function is_inline_data( string $src ): bool {
		return str_starts_with( $src, 'data:' ) || str_starts_with( $src, 'blob:' );
	}

	/**
	 * Returns representative crawl URLs for the given surface.
	 */
	private function get_crawl_urls( string $surface ): array {
		return match ( $surface ) {
			'frontend' => array( home_url( '/' ) ),
			// No admin_url() target: an anonymous wp_remote_get() to wp-admin
			// never sees real admin content -- WordPress redirects a logged-out
			// request to wp-login.php, which the 'login' surface already crawls
			// directly. Anonymously requesting wp-admin has also been observed
			// to trigger a fatal error on some hosts/security plugins that
			// don't expect a bot-like request there, surfacing as a confusing
			// crawl_http_error for admins running a scan. Real admin-surface
			// inline content is still captured passively by Hash_Manager on
			// every genuine logged-in admin page view (admin_head/admin_footer);
			// external admin-surface sources have no discovery path today and
			// must come from violation reports in the interim, same as
			// connect-src/worker-src.
			'admin'    => array(),
			'login'    => array( wp_login_url() ),
			default    => array(),
		};
	}
}
