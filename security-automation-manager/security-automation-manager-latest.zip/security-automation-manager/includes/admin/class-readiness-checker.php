<?php
/**
 * Plugin-specific operational readiness checks.
 */

declare( strict_types=1 );

namespace WP_SAM\Admin;

use WP_SAM\Activator;
use WP_SAM\CSP\Csp_Surfaces;
use WP_SAM\CSP\Policy_Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Readiness_Checker {

	/**
	 * Builds the readiness report.
	 *
	 * @return array Plugin details, schema health and runtime health.
	 */
	public function get_report(): array {
		return array(
			'plugin' => $this->get_plugin_details(),
			'schema' => $this->get_schema_health(),
			'health' => $this->get_runtime_health(),
		);
	}

	/**
	 * Reports the plugin and database schema versions.
	 *
	 * @return array Rows with a label, value and status.
	 */
	private function get_plugin_details(): array {
		$installed_schema = (string) get_option( 'wp_sam_db_version', '0' );

		return array(
			array(
				'label'  => __( 'Plugin version', 'vcns-security-automation-manager' ),
				'value'  => WP_SAM_VERSION,
				'status' => 'pass',
			),
			array(
				'label'  => __( 'Database schema version', 'vcns-security-automation-manager' ),
				'value'  => sprintf(
					/* translators: 1: installed schema version, 2: code schema version */
					__( 'Installed %1$s, code expects %2$s', 'vcns-security-automation-manager' ),
					$installed_schema,
					WP_SAM_DB_VERSION
				),
				'status' => (string) WP_SAM_DB_VERSION === $installed_schema ? 'pass' : 'fail',
			),
			array(
				'label'  => __( 'Plugin file', 'vcns-security-automation-manager' ),
				'value'  => plugin_basename( WP_SAM_FILE ),
				'status' => 'pass',
			),
			array(
				'label'  => __( 'Table prefix in use', 'vcns-security-automation-manager' ),
				'value'  => $this->get_table_prefix(),
				'status' => 'pass',
			),
		);
	}

	/**
	 * Reports whether each plugin table exists and how many rows it holds.
	 *
	 * @return array Rows with a label, value and status.
	 */
	private function get_schema_health(): array {
		global $wpdb;

		$health = array();
		foreach ( Activator::get_table_suffixes() as $suffix ) {
			$table  = $wpdb->prefix . $suffix;
			$exists = $this->table_exists( $table );
			$count  = null;

			if ( $exists ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
			}

			$health[] = array(
				'table'  => $table,
				'status' => $exists ? 'pass' : 'fail',
				'rows'   => $count,
			);
		}

		return $health;
	}

	/**
	 * Reports the runtime configuration, such as the report endpoint and policy profiles.
	 *
	 * @return array Rows with a label, value and status.
	 */
	private function get_runtime_health(): array {
		$report_endpoint = (string) get_option( 'wp_sam_report_endpoint_url', '' );
		if ( '' === trim( $report_endpoint ) ) {
			$report_endpoint = rest_url( 'sam/v1/report' );
		}

		// CSP's own surfaces only: an older install's 'api' profile row stays
		// in the table but isn't expected or counted (see Csp_Surfaces).
		$expected_profiles = count( Csp_Surfaces::ALL );
		$profile_count     = $this->count_table_rows_where(
			'csp_policy_profiles',
			'surface IN (' . Csp_Surfaces::sql_list() . ')'
		);
		$version_count     = $this->count_table_rows_where( 'sam_policy_versions', '1=1' );

		return array(
			array(
				'label'  => __( 'Required policy profiles', 'vcns-security-automation-manager' ),
				'value'  => sprintf(
					/* translators: 1: policy profile count, 2: number of CSP surfaces expected */
					__( '%1$d of %2$d expected surfaces are present', 'vcns-security-automation-manager' ),
					$profile_count,
					$expected_profiles
				),
				'status' => $expected_profiles === $profile_count ? 'pass' : 'fail',
			),
			array(
				'label'  => __( 'Policy version snapshots', 'vcns-security-automation-manager' ),
				'value'  => sprintf(
					/* translators: %d: policy version count */
					__( '%d snapshot records found', 'vcns-security-automation-manager' ),
					$version_count
				),
				'status' => $version_count >= $expected_profiles ? 'pass' : 'warning',
			),
			array(
				'label'  => __( 'Reporting endpoint', 'vcns-security-automation-manager' ),
				'value'  => $report_endpoint,
				'status' => $this->is_valid_http_url( $report_endpoint ) ? 'pass' : 'fail',
			),
			array(
				'label'  => __( 'Policy header emission', 'vcns-security-automation-manager' ),
				'value'  => $this->policy_header_summary(),
				'status' => 'pass',
			),
			array(
				'label'  => __( 'Daily scan schedule', 'vcns-security-automation-manager' ),
				'value'  => wp_next_scheduled( 'wp_sam_daily_scan' )
					? __( 'Scheduled', 'vcns-security-automation-manager' )
					: __( 'Not scheduled', 'vcns-security-automation-manager' ),
				'status' => wp_next_scheduled( 'wp_sam_daily_scan' ) ? 'pass' : 'warning',
			),
			array(
				'label'  => __( 'Automation default posture', 'vcns-security-automation-manager' ),
				'value'  => $this->automation_modes_summary(),
				'status' => 'pass',
			),
		);
	}

	/**
	 * Counts rows of a plugin table that match a fixed condition.
	 *
	 * @param string $suffix Table name without the prefix.
	 * @param string $where  Trusted SQL condition supplied by this class, never user input.
	 * @return int Number of rows, or 0 when the table is missing.
	 */
	private function count_table_rows_where( string $suffix, string $where ): int {
		global $wpdb;

		$table = $wpdb->prefix . $suffix;
		if ( ! $this->table_exists( $table ) ) {
			return 0;
		}

		// The table suffix and where clause are fixed by this class, never user input.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" );
	}

	/**
	 * Checks whether a database table exists.
	 *
	 * @param string $table Full table name.
	 * @return bool True when it exists.
	 */
	private function table_exists( string $table ): bool {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
	}

	/**
	 * Returns the WordPress table prefix.
	 *
	 * @return string Table prefix.
	 */
	private function get_table_prefix(): string {
		global $wpdb;

		return $wpdb->prefix;
	}

	/**
	 * Checks that a URL is http or https with a host.
	 *
	 * @param string $url URL to check.
	 * @return bool True when valid.
	 */
	private function is_valid_http_url( string $url ): bool {
		$parts  = wp_parse_url( $url );
		$scheme = is_array( $parts ) ? strtolower( (string) ( $parts['scheme'] ?? '' ) ) : '';
		$host   = is_array( $parts ) ? (string) ( $parts['host'] ?? '' ) : '';

		return '' !== $host && in_array( $scheme, array( 'http', 'https' ), true );
	}

	/**
	 * Summarises each surface's automation mode as text.
	 *
	 * @return string Summary text.
	 */
	private function automation_modes_summary(): string {
		$config = get_option( 'wp_sam_automation_config', array() );
		if ( ! is_array( $config ) || empty( $config ) ) {
			return __( 'No automation configuration found', 'vcns-security-automation-manager' );
		}

		$modes = array();
		foreach ( Csp_Surfaces::ALL as $surface ) {
			$surface_config = $config[ $surface ] ?? array();
			$modes[]        = $surface . ': ' . ( is_array( $surface_config ) ? ( $surface_config['mode'] ?? 'manual' ) : 'manual' );
		}

		return implode( ', ', $modes );
	}

	/**
	 * Describes which policy header name is in use.
	 *
	 * @return string Summary text.
	 */
	private function policy_header_summary(): string {
		$custom = Policy_Builder::sanitize_custom_policy_header_name( get_option( 'wp_sam_policy_header_name', '' ) );
		if ( '' !== $custom ) {
			return sprintf(
				/* translators: %s: custom policy header name */
				__( 'Custom origin header: %s', 'vcns-security-automation-manager' ),
				$custom
			);
		}

		return sprintf(
			/* translators: 1: report-only header name, 2: enforce header name */
			__( 'Mode based: %1$s or %2$s', 'vcns-security-automation-manager' ),
			Policy_Builder::DEFAULT_REPORT_ONLY_HEADER,
			Policy_Builder::DEFAULT_ENFORCE_HEADER
		);
	}
}
