<?php
/**
 * Admin view: Continuous Intelligence -- Layer 3 of the roadmap's five
 * protection layers. Three tabs:
 *
 * - Events: whatever the Request Observation Framework has recorded in
 *   sam_request_events (Phase 3B/3C), using the same Table_Query sort/
 *   filter/pagination conventions as the CSP Violations and Cross-Origin
 *   Report-Only Evidence tabs.
 * - Identities: resolved request identities from sam_scanner_identities
 *   (Phase 3D). Recognition (automatic) is shown distinctly from
 *   authorisation (an explicit administrator decision) -- see
 *   Intelligence\Scanner_Identity_Store's docblock for why the two can
 *   never be conflated.
 * - Vendors: the known-identity catalogue (sam_scanner_vendors,
 *   Phase 3D) Identity_Resolver matches claimed identities against.
 *   Built-in rows are editable but not deletable.
 *
 * Rendered by Admin_UI::render_intelligence().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_SAM\Admin\Table_Query;
use WP_SAM\Intelligence\Bot_Classifier;
use WP_SAM\Intelligence\Scanner_Identity_Store;
use WP_SAM\Intelligence\Scanner_Vendor_Store;
use WP_SAM\Intelligence\Traffic_Block_Store;

global $wpdb;

$base_url     = admin_url( 'admin.php?page=security-automation-manager-intelligence' );
$tab          = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'events'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$allowed_tabs = array( 'events', 'identities', 'vendors' );
if ( ! in_array( $tab, $allowed_tabs, true ) ) {
	$tab = 'events';
}

$tab_help = array(
	'events'     => array(
		'label'       => __( 'Events', 'vcns-security-automation-manager' ),
		'description' => __( 'Requests matched by a registered detector family.', 'vcns-security-automation-manager' ),
	),
	'identities' => array(
		'label'       => __( 'Identities', 'vcns-security-automation-manager' ),
		'description' => __( 'Claimed identities resolved from real traffic. Recognition is automatic; authorisation is always an explicit decision below.', 'vcns-security-automation-manager' ),
	),
	'vendors'    => array(
		'label'       => __( 'Vendors', 'vcns-security-automation-manager' ),
		'description' => __( 'The known-identity catalogue new traffic is matched against. Add your own verified commercial scanner vendors here.', 'vcns-security-automation-manager' ),
	),
);
?>
<div class="wrap wp-sam-wrap">
	<h1><?php esc_html_e( 'Continuous Intelligence', 'vcns-security-automation-manager' ); ?></h1>

	<p>
		<?php esc_html_e( 'Layer 3 of this plugin\'s protection model: request observation and classification, independent of the enforced header policies above. Which detector families run, and whether a match stays pure evidence or feeds progressive blocking, is configured on Traffic Controls\' Detectors tab -- this page is where you read what they\'ve actually found, who\'s making the requests, and the vendor catalogue those identities are checked against.', 'vcns-security-automation-manager' ); ?>
	</p>

	<nav class="nav-tab-wrapper wp-sam-tab-wrapper" role="tablist" aria-label="<?php esc_attr_e( 'Continuous Intelligence sections', 'vcns-security-automation-manager' ); ?>">
		<?php foreach ( $tab_help as $tab_key => $tab_data ) : ?>
		<a class="nav-tab<?php echo $tab_key === $tab ? ' nav-tab-active' : ''; ?>"
			href="<?php echo esc_url( add_query_arg( 'tab', $tab_key, $base_url ) ); ?>"
			role="tab"
			title="<?php echo esc_attr( $tab_data['description'] ); ?>"
			<?php echo $tab_key === $tab ? 'aria-selected="true" aria-current="page"' : 'aria-selected="false"'; ?>>
			<?php echo esc_html( $tab_data['label'] ); ?>
		</a>
		<?php endforeach; ?>
	</nav>
	<div class="wp-sam-tab-help" role="note">
		<strong><?php echo esc_html( $tab_help[ $tab ]['label'] ); ?>:</strong>
		<?php echo esc_html( $tab_help[ $tab ]['description'] ); ?>
	</div>

	<?php if ( 'events' === $tab ) : ?>

		<?php
		$surfaces   = array( 'frontend', 'admin', 'login', 'api' );
		$severities = array( 'low', 'medium', 'high', 'critical', 'unknown' );
		$per_page   = 20;

		$i_surface   = Table_Query::text_param( 'i_surface' );
		$i_severity  = Table_Query::text_param( 'i_severity' );
		$i_detector  = Table_Query::text_param( 'i_detector' );
		$i_occ_min   = Table_Query::int_param( 'i_occ_min' );
		$i_seen_from = Table_Query::text_param( 'i_seen_from' );
		$i_seen_to   = Table_Query::text_param( 'i_seen_to' );

		$where = array( '1=1' );
		$args  = array();
		foreach (
			array(
				Table_Query::equals_where( 'surface', $i_surface ),
				Table_Query::equals_where( 'severity', $i_severity ),
				Table_Query::like_where_any( $wpdb, array( 'detector_id', 'detector_family' ), $i_detector ),
				Table_Query::numeric_gte_where( 'occurrence_count', $i_occ_min ),
				Table_Query::date_range_where( 'last_seen_at', $i_seen_from, $i_seen_to ),
			) as $fragment
		) {
			if ( null === $fragment ) {
				continue;
			}
			$where[] = $fragment['sql'];
			array_push( $args, ...$fragment['args'] );
		}
		$where_sql = implode( ' AND ', $where );

		$sort_whitelist = array(
			'surface'     => array(
				'expr'        => 'surface',
				'default_dir' => 'asc',
			),
			'detector'    => array(
				'expr'        => 'detector_id',
				'default_dir' => 'asc',
			),
			'family'      => array(
				'expr'        => 'detector_family',
				'default_dir' => 'asc',
			),
			'severity'    => array(
				'expr'        => 'severity',
				'default_dir' => 'asc',
			),
			'occurrences' => array(
				'expr'        => 'occurrence_count',
				'default_dir' => 'desc',
			),
			'first_seen'  => array(
				'expr'        => 'first_seen_at',
				'default_dir' => 'desc',
			),
			'last_seen'   => array(
				'expr'        => 'last_seen_at',
				'default_dir' => 'desc',
			),
		);
		$sort           = Table_Query::resolve_sort(
			$sort_whitelist,
			'last_seen',
			isset( $_GET['sort'] ) ? sanitize_text_field( wp_unslash( $_GET['sort'] ) ) : null, // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			isset( $_GET['dir'] ) ? sanitize_text_field( wp_unslash( $_GET['dir'] ) ) : null // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		);

		$state_args = array_filter(
			array(
				'tab'         => 'events',
				'sort'        => $sort['key'],
				'dir'         => strtolower( $sort['dir'] ),
				'i_surface'   => $i_surface,
				'i_severity'  => $i_severity,
				'i_detector'  => $i_detector,
				'i_occ_min'   => $i_occ_min,
				'i_seen_from' => $i_seen_from,
				'i_seen_to'   => $i_seen_to,
			)
		);

		$count_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}sam_request_events WHERE {$where_sql}";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count_sql = $wpdb->prepare( $count_sql, ...$args );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $count_sql );

		$pages    = max( 1, (int) ceil( $total / $per_page ) );
		$page_num = min( max( 1, (int) ( isset( $_GET['i_paged'] ) ? $_GET['i_paged'] : 1 ) ), $pages ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$offset   = ( $page_num - 1 ) * $per_page;

		$data_args = array_merge( $args, array( $per_page, $offset ) );
		$data_sql  = "SELECT * FROM {$wpdb->prefix}sam_request_events WHERE {$where_sql} " . Table_Query::order_by_sql( $sort ) . ' LIMIT %d OFFSET %d';
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$data_sql = $wpdb->prepare( $data_sql, ...$data_args );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$events_raw = $wpdb->get_results( $data_sql, ARRAY_A );
		$events     = ! empty( $events_raw ) ? $events_raw : array();

		$detector_count = count( \WP_SAM\Intelligence\Detector_Registry::keys() );
		?>

		<p class="description">
			<?php esc_html_e( 'Each row is a Finding -- evidence that a registered detector matched something about a request, not a log of every individual hit. Repeated matches from the same source against the same detector on the same surface collapse into one row: Occurrences counts how many times it happened, and First Seen/Last Seen bracket when. A row here is never, by itself, proof that anything was blocked -- whether this detector\'s matches stay pure evidence or actually feed the progressive-response block ladder is a per-family setting on Traffic Controls\' Detectors tab. Use the icon in the Details column to see the specific evidence captured for a row.', 'vcns-security-automation-manager' ); ?>
		</p>

		<?php if ( 0 === $detector_count ) : ?>
		<div class="notice notice-info inline" style="padding:12px 16px;margin:1em 0;">
			<p style="margin-top:0;">
				<?php esc_html_e( 'No detectors are registered yet. Requests are observed and classified, but nothing is currently evaluated against them, so this table stays empty.', 'vcns-security-automation-manager' ); ?>
			</p>
		</div>
		<?php endif; ?>

		<details class="wp-sam-filter-form">
			<summary><?php esc_html_e( 'Filters', 'vcns-security-automation-manager' ); ?></summary>
			<form method="get" action="">
				<input type="hidden" name="page" value="security-automation-manager-intelligence" />
				<input type="hidden" name="tab" value="events" />
				<label>
					<?php esc_html_e( 'Surface', 'vcns-security-automation-manager' ); ?>
					<select name="i_surface">
						<option value=""><?php esc_html_e( 'Any', 'vcns-security-automation-manager' ); ?></option>
						<?php foreach ( $surfaces as $s ) : ?>
						<option value="<?php echo esc_attr( $s ); ?>" <?php selected( $i_surface, $s ); ?>><?php echo esc_html( ucfirst( $s ) ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label>
					<?php esc_html_e( 'Severity', 'vcns-security-automation-manager' ); ?>
					<select name="i_severity">
						<option value=""><?php esc_html_e( 'Any', 'vcns-security-automation-manager' ); ?></option>
						<?php foreach ( $severities as $sev ) : ?>
						<option value="<?php echo esc_attr( $sev ); ?>" <?php selected( $i_severity, $sev ); ?>><?php echo esc_html( ucfirst( $sev ) ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label>
					<?php esc_html_e( 'Detector contains', 'vcns-security-automation-manager' ); ?>
					<input type="text" name="i_detector" value="<?php echo esc_attr( $i_detector ); ?>" />
				</label>
				<label>
					<?php esc_html_e( 'Occurrences at least', 'vcns-security-automation-manager' ); ?>
					<input type="number" min="0" name="i_occ_min" style="width:80px" value="<?php echo esc_attr( null !== $i_occ_min ? (string) $i_occ_min : '' ); ?>" />
				</label>
				<label>
					<?php esc_html_e( 'Last seen from', 'vcns-security-automation-manager' ); ?>
					<input type="datetime-local" name="i_seen_from" value="<?php echo esc_attr( $i_seen_from ); ?>" />
				</label>
				<label>
					<?php esc_html_e( 'to', 'vcns-security-automation-manager' ); ?>
					<input type="datetime-local" name="i_seen_to" value="<?php echo esc_attr( $i_seen_to ); ?>" />
				</label>
				<?php submit_button( __( 'Filter', 'vcns-security-automation-manager' ), 'secondary', 'filter_events', false ); ?>
			</form>
		</details>

		<div class="wp-sam-table-wrap">
		<table class="widefat striped wp-sam-table wp-sam-violations-table wp-sam-events-table" style="margin-top:1em">
			<thead>
				<tr>
					<?php
					echo Table_Query::sort_header( __( 'Surface', 'vcns-security-automation-manager' ), 'surface', $sort_whitelist, $sort, $state_args, $base_url, 'i_paged', 'wp-sam-col-surface' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes internally.
					echo Table_Query::sort_header( __( 'Detector', 'vcns-security-automation-manager' ), 'detector', $sort_whitelist, $sort, $state_args, $base_url, 'i_paged', 'wp-sam-col-technical' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Table_Query::sort_header( __( 'Family', 'vcns-security-automation-manager' ), 'family', $sort_whitelist, $sort, $state_args, $base_url, 'i_paged', 'wp-sam-col-surface' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Table_Query::sort_header( __( 'Severity', 'vcns-security-automation-manager' ), 'severity', $sort_whitelist, $sort, $state_args, $base_url, 'i_paged', 'wp-sam-col-status' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Table_Query::sort_header( __( 'Occurrences', 'vcns-security-automation-manager' ), 'occurrences', $sort_whitelist, $sort, $state_args, $base_url, 'i_paged', 'wp-sam-col-count' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Table_Query::sort_header( __( 'First Seen', 'vcns-security-automation-manager' ), 'first_seen', $sort_whitelist, $sort, $state_args, $base_url, 'i_paged', 'wp-sam-col-datetime' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Table_Query::sort_header( __( 'Last Seen', 'vcns-security-automation-manager' ), 'last_seen', $sort_whitelist, $sort, $state_args, $base_url, 'i_paged', 'wp-sam-col-datetime' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
					<th class="wp-sam-col-compact"><?php esc_html_e( 'Details', 'vcns-security-automation-manager' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $events as $event ) : ?>
			<tr>
				<td class="wp-sam-col-surface"><?php echo esc_html( ucfirst( (string) $event['surface'] ) ); ?></td>
				<td class="wp-sam-col-technical"><code><?php echo esc_html( (string) $event['detector_id'] ); ?></code></td>
				<td class="wp-sam-col-surface">
					<?php
					// Most built-in detectors return the same string from id()
					// and family() -- family only actually groups something
					// distinct for the handful that group multiple ids under
					// one family (custom rules all share 'custom'; Honeypath
					// reports its family as 'deception'; Tor_Exit_Detector as
					// 'network-intelligence'). Repeating an identical string
					// in both columns for every other row is pure duplication
					// with nothing left to show, so it's collapsed to an
					// em-dash rather than restated.
					echo esc_html( (string) $event['detector_family'] !== (string) $event['detector_id'] ? (string) $event['detector_family'] : '—' );
					?>
				</td>
				<td class="wp-sam-col-status"><?php echo esc_html( ucfirst( (string) $event['severity'] ) ); ?></td>
				<td class="wp-sam-col-count"><?php echo esc_html( number_format( (int) $event['occurrence_count'] ) ); ?></td>
				<td class="wp-sam-col-datetime"><?php echo esc_html( (string) $event['first_seen_at'] ); ?></td>
				<td class="wp-sam-col-datetime"><?php echo esc_html( (string) $event['last_seen_at'] ); ?></td>
				<td class="wp-sam-col-compact">
					<?php
					$event_detail = json_decode( (string) $event['detail'], true );
					$meta_fields  = is_array( $event_detail ) ? $event_detail : array();
					$has_meta     = ! empty( $meta_fields );
					?>
					<?php if ( $has_meta ) : ?>
					<span class="dashicons dashicons-info-outline wp-sam-meta-icon" tabindex="0">
						<span class="wp-sam-meta-popover" role="tooltip">
							<?php foreach ( $meta_fields as $meta_label => $meta_value ) : ?>
							<div class="wp-sam-meta-row">
								<strong><?php echo esc_html( (string) $meta_label ); ?>:</strong>
								<code><?php echo esc_html( is_scalar( $meta_value ) ? (string) $meta_value : wp_json_encode( $meta_value ) ); ?></code>
							</div>
							<?php endforeach; ?>
						</span>
					</span>
					<?php else : ?>
					<span class="dashicons dashicons-info-outline wp-sam-meta-icon wp-sam-meta-icon--empty" title="<?php esc_attr_e( 'No metadata captured for this event', 'vcns-security-automation-manager' ); ?>"></span>
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; ?>
			<?php if ( empty( $events ) ) : ?>
			<tr>
				<td colspan="8">
					<?php if ( $detector_count > 0 ) : ?>
					<p><?php esc_html_e( 'No events recorded yet.', 'vcns-security-automation-manager' ); ?></p>
					<?php else : ?>
					<p><?php esc_html_e( 'No events recorded -- no detectors are registered yet.', 'vcns-security-automation-manager' ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
			<?php endif; ?>
			</tbody>
		</table>
		</div>

		<?php echo Table_Query::pagination( $page_num, $pages, $state_args, $base_url, 'i_paged' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

	<?php elseif ( 'identities' === $tab ) : ?>

		<?php
		$surfaces = array( 'frontend', 'admin', 'login', 'api' );
		$states   = array_merge( Scanner_Identity_Store::AUTOMATIC_STATES, Scanner_Identity_Store::DECISION_STATES );
		$per_page = 20;

		$id_surface = Table_Query::text_param( 'id_surface' );
		$id_state   = Table_Query::text_param( 'id_state' );
		$id_ip      = Table_Query::text_param( 'id_ip' );

		$where = array( '1=1' );
		$args  = array();
		foreach (
			array(
				Table_Query::equals_where( 'surface', $id_surface ),
				Table_Query::equals_where( 'verification_state', $id_state ),
				Table_Query::like_where_any( $wpdb, array( 'ip' ), $id_ip ),
			) as $fragment
		) {
			if ( null === $fragment ) {
				continue;
			}
			$where[] = $fragment['sql'];
			array_push( $args, ...$fragment['args'] );
		}
		$where_sql = implode( ' AND ', $where );

		$sort_whitelist = array(
			'identity'    => array(
				'expr'        => 'claimed_identity',
				'default_dir' => 'asc',
			),
			'state'       => array(
				'expr'        => 'verification_state',
				'default_dir' => 'asc',
			),
			'occurrences' => array(
				'expr'        => 'occurrence_count',
				'default_dir' => 'desc',
			),
			'last_seen'   => array(
				'expr'        => 'last_seen_at',
				'default_dir' => 'desc',
			),
		);
		$sort           = Table_Query::resolve_sort(
			$sort_whitelist,
			'occurrences',
			isset( $_GET['sort'] ) ? sanitize_text_field( wp_unslash( $_GET['sort'] ) ) : null, // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			isset( $_GET['dir'] ) ? sanitize_text_field( wp_unslash( $_GET['dir'] ) ) : null // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		);

		$state_args = array_filter(
			array(
				'tab'        => 'identities',
				'sort'       => $sort['key'],
				'dir'        => strtolower( $sort['dir'] ),
				'id_surface' => $id_surface,
				'id_state'   => $id_state,
				'id_ip'      => $id_ip,
			)
		);

		$identities_table = $wpdb->prefix . 'sam_scanner_identities';
		$count_sql        = "SELECT COUNT(*) FROM {$identities_table} WHERE {$where_sql}";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count_sql = $wpdb->prepare( $count_sql, ...$args );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( $count_sql );

		$pages    = max( 1, (int) ceil( $total / $per_page ) );
		$page_num = min( max( 1, (int) ( isset( $_GET['id_paged'] ) ? $_GET['id_paged'] : 1 ) ), $pages ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$offset   = ( $page_num - 1 ) * $per_page;

		$data_args = array_merge( $args, array( $per_page, $offset ) );
		$data_sql  = "SELECT * FROM {$identities_table} WHERE {$where_sql} " . Table_Query::order_by_sql( $sort ) . ' LIMIT %d OFFSET %d';
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$data_sql = $wpdb->prepare( $data_sql, ...$data_args );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$identities_raw = $wpdb->get_results( $data_sql, ARRAY_A );
		$identities     = ! empty( $identities_raw ) ? $identities_raw : array();

		$vendor_store   = new Scanner_Vendor_Store();
		$vendors_by_key = array();
		foreach ( $vendor_store->all() as $v ) {
			$vendors_by_key[ $v['vendor_key'] ] = $v;
		}

		$state_labels = array(
			'unknown'                       => __( 'Unknown', 'vcns-security-automation-manager' ),
			'known_commercial_scanner'      => __( 'Known commercial scanner', 'vcns-security-automation-manager' ),
			'known_research_scanner'        => __( 'Known research scanner', 'vcns-security-automation-manager' ),
			'known_crawler'                 => __( 'Known crawler', 'vcns-security-automation-manager' ),
			'identity_conflict'             => __( 'Identity conflict', 'vcns-security-automation-manager' ),
			'loopback'                      => __( 'Loopback (this server)', 'vcns-security-automation-manager' ),
			'customer_authorised'           => __( 'Authorised', 'vcns-security-automation-manager' ),
			'explicitly_denied'             => __( 'Denied', 'vcns-security-automation-manager' ),
			'previously_authorised_expired' => __( 'Authorisation expired', 'vcns-security-automation-manager' ),
		);

		// Bot classification (Phase 4C, .roadmap/phase3_early_plan.md §10):
		// combines this row's already-recorded identity signal with the
		// matching Traffic_Block_Store row's request-rate escalation, if
		// any -- see Bot_Classifier's own docblock. Computed here, on
		// demand, for this page only; nothing new is written to the
		// database.
		$bot_classifier        = new Bot_Classifier();
		$traffic_blocks        = new Traffic_Block_Store();
		$classification_labels = array(
			'admin_authorised'            => __( 'Authorised by admin', 'vcns-security-automation-manager' ),
			'admin_denied'                => __( 'Denied by admin', 'vcns-security-automation-manager' ),
			'admin_authorisation_expired' => __( 'Authorisation expired', 'vcns-security-automation-manager' ),
			'loopback'                    => __( 'Loopback -- this server calling itself', 'vcns-security-automation-manager' ),
			'verified_crawler'            => __( 'Verified crawler', 'vcns-security-automation-manager' ),
			'claimed_crawler_unverified'  => __( 'Claimed crawler (unverified)', 'vcns-security-automation-manager' ),
			'enumerating_scraper'         => __( 'Enumerating (sequential ID pattern)', 'vcns-security-automation-manager' ),
			'scripted_timing'             => __( 'Scripted timing (uniform request interval)', 'vcns-security-automation-manager' ),
			'error_probing_scanner'       => __( 'Error probing (repeated 4xx/5xx)', 'vcns-security-automation-manager' ),
			'aggressive_unidentified'     => __( 'Aggressive / rate-escalated', 'vcns-security-automation-manager' ),
			'unclassified'                => __( 'Unclassified', 'vcns-security-automation-manager' ),
		);
		?>

		<div class="notice notice-info inline" style="padding:12px 16px;margin:1em 0;">
			<p style="margin-top:0;">
				<?php esc_html_e( 'Recognition is not authorisation. A source matching a known vendor pattern is only ever a recognition signal -- it does not bypass any control until you explicitly authorise it below.', 'vcns-security-automation-manager' ); ?>
			</p>
		</div>

		<p class="description">
			<?php esc_html_e( 'State reflects this plugin\'s own automatic recognition -- Unknown, one of three known-vendor categories, or Loopback -- refreshed on every request, unless an administrator\'s own decision (Authorised, Denied, or Authorisation expired) already occupies that row; a decision always wins and is never silently overwritten by new automatic traffic from the same source. Classification adds a further judgement computed fresh on every page load, purely for display -- nothing it produces is written back to the database, which is also why, unlike State, it has no sort or filter of its own here.', 'vcns-security-automation-manager' ); ?>
		</p>

		<p class="description">
			<?php esc_html_e( 'A claimed identity only becomes Verified crawler once it also matches that vendor\'s own published network data -- a CIDR range or reverse-DNS suffix recorded on the Vendors tab. Claimed crawler (unverified) means the User-Agent string alone claims a known vendor\'s identity without that match: exactly the impersonation case worth a closer look, since a User-Agent is just a header any script can set to anything it likes. Enumerating (sequential ID pattern), Scripted timing, Error probing, and Aggressive / rate-escalated all describe an unrecognised source instead -- the first from a fixed-step pattern in its recent request paths (e.g. /product/101, /product/102, /product/103), the second from its last several requests arriving at a suspiciously uniform interval (a script sleeping a fixed duration between requests, rather than a person\'s naturally irregular browsing), the third from most of its recent requests coming back as an HTTP error (most often 404 -- a scanner trying paths that don\'t exist rather than a person or crawler following real links), the fourth from having already escalated through Traffic Controls\' own progressive-response ladder. None of these implies another, and most ordinary traffic triggers none of them, landing on Unclassified.', 'vcns-security-automation-manager' ); ?>
		</p>

		<p class="description">
			<?php esc_html_e( "The ASN/country line under an IP (when shown) fills in the same way State does -- only once a detector has already found something about that source, reusing that same lookup rather than resolving network data for every ordinary visitor. A blank line isn't a failed lookup; it usually just means this source has never yet tripped a detector. See Traffic Controls' Network Intelligence tab for what ASN and Geo-IP actually are and how they're resolved.", 'vcns-security-automation-manager' ); ?>
		</p>

		<details class="wp-sam-filter-form">
			<summary><?php esc_html_e( 'Filters', 'vcns-security-automation-manager' ); ?></summary>
			<form method="get" action="">
				<input type="hidden" name="page" value="security-automation-manager-intelligence" />
				<input type="hidden" name="tab" value="identities" />
				<label>
					<?php esc_html_e( 'Surface', 'vcns-security-automation-manager' ); ?>
					<select name="id_surface">
						<option value=""><?php esc_html_e( 'Any', 'vcns-security-automation-manager' ); ?></option>
						<?php foreach ( $surfaces as $s ) : ?>
						<option value="<?php echo esc_attr( $s ); ?>" <?php selected( $id_surface, $s ); ?>><?php echo esc_html( ucfirst( $s ) ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label>
					<?php esc_html_e( 'State', 'vcns-security-automation-manager' ); ?>
					<select name="id_state">
						<option value=""><?php esc_html_e( 'Any', 'vcns-security-automation-manager' ); ?></option>
						<?php foreach ( $states as $st ) : ?>
						<option value="<?php echo esc_attr( $st ); ?>" <?php selected( $id_state, $st ); ?>><?php echo esc_html( $state_labels[ $st ] ?? $st ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label>
					<?php esc_html_e( 'IP contains', 'vcns-security-automation-manager' ); ?>
					<input type="text" name="id_ip" value="<?php echo esc_attr( $id_ip ); ?>" />
				</label>
				<?php submit_button( __( 'Filter', 'vcns-security-automation-manager' ), 'secondary', 'filter_identities', false ); ?>
			</form>
		</details>

		<div class="wp-sam-table-wrap">
		<table class="widefat striped wp-sam-table wp-sam-violations-table wp-sam-identities-table" style="margin-top:1em">
			<thead>
				<tr>
					<?php
					echo Table_Query::sort_header( __( 'Claimed Identity', 'vcns-security-automation-manager' ), 'identity', $sort_whitelist, $sort, $state_args, $base_url, 'id_paged', 'wp-sam-col-primary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
					<th class="wp-sam-col-technical"><?php esc_html_e( 'IP', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-surface"><?php esc_html_e( 'Surface', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-technical"><?php esc_html_e( 'Vendor Source', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-description"><?php esc_html_e( 'Classification', 'vcns-security-automation-manager' ); ?></th>
					<?php
					echo Table_Query::sort_header( __( 'State', 'vcns-security-automation-manager' ), 'state', $sort_whitelist, $sort, $state_args, $base_url, 'id_paged', 'wp-sam-col-status' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Table_Query::sort_header( __( 'Occurrences', 'vcns-security-automation-manager' ), 'occurrences', $sort_whitelist, $sort, $state_args, $base_url, 'id_paged', 'wp-sam-col-count' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo Table_Query::sort_header( __( 'Last Seen', 'vcns-security-automation-manager' ), 'last_seen', $sort_whitelist, $sort, $state_args, $base_url, 'id_paged', 'wp-sam-col-datetime' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
					<th class="wp-sam-col-actions"><?php esc_html_e( 'Decision', 'vcns-security-automation-manager' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $identities as $row ) : ?>
				<?php
				$vendor_key     = (string) $row['vendor_key'];
				$vendor         = $vendors_by_key[ $vendor_key ] ?? null;
				$state          = (string) $row['verification_state'];
				$is_decided     = in_array( $state, Scanner_Identity_Store::DECISION_STATES, true );
				$traffic_block  = $traffic_blocks->get( (string) $row['ip'], (string) $row['surface'] );
				$classification = $bot_classifier->classify( $row, $traffic_block );
				$recent_paths   = json_decode( (string) ( $row['recent_paths'] ?? '' ), true );
				$recent_paths   = is_array( $recent_paths ) ? $recent_paths : array();
				?>
			<tr>
				<td class="wp-sam-col-primary"><?php echo esc_html( '' !== (string) $row['claimed_identity'] ? (string) $row['claimed_identity'] : __( '(unrecognised)', 'vcns-security-automation-manager' ) ); ?></td>
				<td class="wp-sam-col-technical">
					<code><?php echo esc_html( (string) $row['ip'] ); ?></code>
					<?php
					$network_bits = array_filter(
						array(
							'' !== (string) ( $row['asn'] ?? '' ) ? 'AS' . (string) $row['asn'] . ( '' !== (string) ( $row['asn_org'] ?? '' ) ? ' (' . (string) $row['asn_org'] . ')' : '' ) : '',
							(string) ( $row['geo_country'] ?? '' ),
						)
					);
					?>
					<?php if ( ! empty( $network_bits ) ) : ?>
						<br /><small class="description"><?php echo esc_html( implode( ' -- ', $network_bits ) ); ?></small>
					<?php endif; ?>
				</td>
				<td class="wp-sam-col-surface"><?php echo esc_html( ucfirst( (string) $row['surface'] ) ); ?></td>
				<td class="wp-sam-col-technical">
					<?php if ( null !== $vendor && '' !== (string) $vendor['source_url'] ) : ?>
						<a href="<?php echo esc_url( (string) $vendor['source_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Source', 'vcns-security-automation-manager' ); ?></a>
					<?php else : ?>
						&mdash;
					<?php endif; ?>
				</td>
				<td class="wp-sam-col-description">
					<span<?php echo ! empty( $recent_paths ) ? ' title="' . esc_attr( implode( ', ', $recent_paths ) ) . '"' : ''; ?>>
						<?php echo esc_html( $classification_labels[ $classification ] ?? $classification ); ?>
					</span>
					<?php if ( ! empty( $recent_paths ) ) : ?>
						<br /><small class="description"><?php echo esc_html( sprintf( /* translators: %d: number of recently observed request paths */ _n( '%d recent path logged', '%d recent paths logged', count( $recent_paths ), 'vcns-security-automation-manager' ), count( $recent_paths ) ) ); ?></small>
					<?php endif; ?>
				</td>
				<td class="wp-sam-col-status"><?php echo esc_html( $state_labels[ $state ] ?? $state ); ?></td>
				<td class="wp-sam-col-count"><?php echo esc_html( number_format( (int) $row['occurrence_count'] ) ); ?></td>
				<td class="wp-sam-col-datetime"><?php echo esc_html( (string) $row['last_seen_at'] ); ?></td>
				<td class="wp-sam-col-actions">
					<?php if ( 'loopback' === $state ) : ?>
						<span class="description wp-sam-auto-authorised" title="<?php esc_attr_e( 'This server calling itself is treated as authorised automatically. If a reverse proxy on this site terminates every visitor connection via loopback, deny it below to override that.', 'vcns-security-automation-manager' ); ?>"><?php esc_html_e( 'Auto-authorised (loopback)', 'vcns-security-automation-manager' ); ?></span>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-top:4px">
							<?php wp_nonce_field( 'wp_sam_scanner_identity_decide' ); ?>
							<input type="hidden" name="action" value="wp_sam_scanner_identity_decide" />
							<input type="hidden" name="identity_id" value="<?php echo esc_attr( (string) $row['id'] ); ?>" />
							<input type="hidden" name="wp_sam_return_tab" value="identities" />
							<input type="text" name="note" placeholder="<?php esc_attr_e( 'Reason', 'vcns-security-automation-manager' ); ?>" required style="width:200px" />
							<button type="submit" name="decision" value="deny" class="button button-small"><?php esc_html_e( 'Not this server? Deny', 'vcns-security-automation-manager' ); ?></button>
						</form>
					<?php elseif ( $is_decided ) : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
							<?php wp_nonce_field( 'wp_sam_scanner_identity_decide' ); ?>
							<input type="hidden" name="action" value="wp_sam_scanner_identity_decide" />
							<input type="hidden" name="identity_id" value="<?php echo esc_attr( (string) $row['id'] ); ?>" />
							<input type="hidden" name="decision" value="clear" />
							<input type="hidden" name="wp_sam_return_tab" value="identities" />
							<input type="text" name="note" placeholder="<?php esc_attr_e( 'Reason', 'vcns-security-automation-manager' ); ?>" required style="width:200px" />
							<?php submit_button( __( 'Clear decision', 'vcns-security-automation-manager' ), 'secondary small', '', false ); ?>
						</form>
					<?php else : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block">
							<?php wp_nonce_field( 'wp_sam_scanner_identity_decide' ); ?>
							<input type="hidden" name="action" value="wp_sam_scanner_identity_decide" />
							<input type="hidden" name="identity_id" value="<?php echo esc_attr( (string) $row['id'] ); ?>" />
							<input type="hidden" name="wp_sam_return_tab" value="identities" />
							<input type="text" name="note" placeholder="<?php esc_attr_e( 'Reason', 'vcns-security-automation-manager' ); ?>" required style="width:200px" />
							<button type="submit" name="decision" value="authorise" class="button button-primary button-small"><?php esc_html_e( 'Authorise', 'vcns-security-automation-manager' ); ?></button>
							<button type="submit" name="decision" value="deny" class="button button-small"><?php esc_html_e( 'Deny', 'vcns-security-automation-manager' ); ?></button>
						</form>
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; ?>
			<?php if ( empty( $identities ) ) : ?>
			<tr>
				<td colspan="9"><p><?php esc_html_e( 'No identities recorded yet.', 'vcns-security-automation-manager' ); ?></p></td>
			</tr>
			<?php endif; ?>
			</tbody>
		</table>
		</div>

		<?php echo Table_Query::pagination( $page_num, $pages, $state_args, $base_url, 'id_paged' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

	<?php elseif ( 'vendors' === $tab ) : ?>

		<?php
		$vendor_store    = new Scanner_Vendor_Store();
		$vendors         = $vendor_store->all();
		$category_labels = array(
			'known_commercial_scanner' => __( 'Known commercial scanner', 'vcns-security-automation-manager' ),
			'known_research_scanner'   => __( 'Known research scanner', 'vcns-security-automation-manager' ),
			'known_crawler'            => __( 'Known crawler', 'vcns-security-automation-manager' ),
			'custom'                   => __( 'Custom', 'vcns-security-automation-manager' ),
		);

		// Built-in rows are editable (e.g. to add a vendor-published CIDR
		// range once verified) but not deletable -- Scanner_Vendor_Store's
		// own docblock. upsert() already updates-in-place for any existing
		// vendor_key without touching is_builtin, so editing a built-in row
		// only ever needed a way to reach the form pre-filled; nothing on
		// the storage side changes here.
		$edit_vendor_key = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$editing_vendor  = '' !== $edit_vendor_key ? $vendor_store->get( $edit_vendor_key ) : null;
		?>

		<p class="description">
			<?php esc_html_e( 'This is the catalogue this plugin checks a request\'s User-Agent against -- a match here is what turns an anonymous request into a claimed identity on the Identities tab at all. Verification method controls how much that match is actually worth: "None" means the User-Agent string is the entire signal, which is worth very little on its own since it\'s trivially spoofed; "Published CIDR ranges" and "Forward-confirmed reverse DNS" let a claimed identity be checked against network data the vendor itself publishes, which is what promotes a match from Claimed crawler (unverified) to Verified crawler on the Identities tab. Built-in rows ship with only a small, deliberately conservative seed of well-documented crawlers -- commercial scanner vendors are never seeded with guessed network ranges, since asserting a stale or fabricated range in a security product would be worse than asserting none. Add your own vendor once you have network data you trust, with its source recorded.', 'vcns-security-automation-manager' ); ?>
		</p>

		<p class="description">
			<a href="https://github.com/vcns/security-automation-manager/blob/main/docs/scanner-vendor-research.md" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Vendor research: sourcing for every built-in entry, plus researched-but-not-built-in commercial scanners and monitoring bots', 'vcns-security-automation-manager' ); ?></a>
		</p>
		<div class="wp-sam-table-wrap">
		<table class="widefat striped wp-sam-table wp-sam-violations-table wp-sam-vendors-table" style="margin-top:1em">
			<thead>
				<tr>
					<th class="wp-sam-col-primary"><?php esc_html_e( 'Vendor', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-surface"><?php esc_html_e( 'Category', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-technical"><?php esc_html_e( 'UA pattern', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-technical"><?php esc_html_e( 'Verification', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-technical"><?php esc_html_e( 'Source', 'vcns-security-automation-manager' ); ?></th>
					<th class="wp-sam-col-actions"><?php esc_html_e( 'Actions', 'vcns-security-automation-manager' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $vendors as $vendor ) : ?>
			<tr>
				<td class="wp-sam-col-primary">
					<?php echo esc_html( (string) $vendor['vendor_name'] ); ?>
					<?php if ( ! empty( $vendor['is_builtin'] ) ) : ?>
						<span class="description">(<?php esc_html_e( 'built-in', 'vcns-security-automation-manager' ); ?>)</span>
					<?php endif; ?>
				</td>
				<td class="wp-sam-col-surface"><?php echo esc_html( $category_labels[ (string) $vendor['category'] ] ?? (string) $vendor['category'] ); ?></td>
				<td class="wp-sam-col-technical"><code><?php echo esc_html( (string) $vendor['ua_pattern'] ); ?></code></td>
				<td class="wp-sam-col-technical"><?php echo esc_html( (string) $vendor['verification_method'] ); ?></td>
				<td class="wp-sam-col-technical">
					<?php if ( '' !== (string) $vendor['source_url'] ) : ?>
						<a href="<?php echo esc_url( (string) $vendor['source_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Link', 'vcns-security-automation-manager' ); ?></a>
					<?php else : ?>
						&mdash;
					<?php endif; ?>
				</td>
				<td class="wp-sam-col-actions">
					<?php
					$vendor_edit_url = add_query_arg(
						array(
							'tab'  => 'vendors',
							'edit' => $vendor['vendor_key'],
						),
						$base_url
					) . '#wp-sam-vendor-form';
					?>
					<a href="<?php echo esc_url( $vendor_edit_url ); ?>" class="button button-small">
						<?php esc_html_e( 'Edit', 'vcns-security-automation-manager' ); ?>
					</a>
					<?php if ( empty( $vendor['is_builtin'] ) ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
						<?php wp_nonce_field( 'wp_sam_scanner_vendor_delete' ); ?>
						<input type="hidden" name="action" value="wp_sam_scanner_vendor_delete" />
						<input type="hidden" name="vendor_key" value="<?php echo esc_attr( (string) $vendor['vendor_key'] ); ?>" />
						<?php submit_button( __( 'Delete', 'vcns-security-automation-manager' ), 'link-delete small', '', false ); ?>
					</form>
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>

		<details class="wp-sam-filter-form" id="wp-sam-vendor-form" style="margin-top:2em"<?php echo null !== $editing_vendor ? ' open' : ''; ?>>
			<summary>
				<?php
				if ( null !== $editing_vendor ) {
					printf(
						/* translators: %s: vendor name being edited */
						esc_html__( 'Edit vendor: %s', 'vcns-security-automation-manager' ),
						esc_html( (string) $editing_vendor['vendor_name'] )
					);
				} else {
					esc_html_e( 'Add a vendor', 'vcns-security-automation-manager' );
				}
				?>
			</summary>
			<p class="description"><?php esc_html_e( 'A source URL is required so the record stays traceable to where the verification method came from.', 'vcns-security-automation-manager' ); ?></p>
			<?php if ( null !== $editing_vendor && ! empty( $editing_vendor['is_builtin'] ) ) : ?>
			<p class="description"><?php esc_html_e( 'This is a built-in vendor -- it can be edited (for example, to add a published CIDR range once verified) but not deleted or renamed.', 'vcns-security-automation-manager' ); ?></p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wp-sam-vendor-form">
				<?php wp_nonce_field( 'wp_sam_scanner_vendor_upsert' ); ?>
			<input type="hidden" name="action" value="wp_sam_scanner_vendor_upsert" />
			<table class="form-table">
				<tr>
					<th><label for="vendor_key"><?php esc_html_e( 'Key', 'vcns-security-automation-manager' ); ?></label></th>
					<td>
						<?php if ( null !== $editing_vendor ) : ?>
							<code><?php echo esc_html( (string) $editing_vendor['vendor_key'] ); ?></code>
							<input type="hidden" id="vendor_key" name="vendor_key" value="<?php echo esc_attr( (string) $editing_vendor['vendor_key'] ); ?>" />
							<p class="description"><?php esc_html_e( "Can't be changed once created -- it's what this update matches against. Delete and re-add under a new key instead.", 'vcns-security-automation-manager' ); ?></p>
						<?php else : ?>
							<input type="text" id="vendor_key" name="vendor_key" required pattern="[a-z0-9_-]+" placeholder="qualys" />
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><label for="vendor_name"><?php esc_html_e( 'Name', 'vcns-security-automation-manager' ); ?></label></th>
					<td><input type="text" id="vendor_name" name="vendor_name" required placeholder="Qualys" value="<?php echo esc_attr( null !== $editing_vendor ? (string) $editing_vendor['vendor_name'] : '' ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="category"><?php esc_html_e( 'Category', 'vcns-security-automation-manager' ); ?></label></th>
					<td>
						<select id="category" name="category">
							<?php foreach ( $category_labels as $cat_key => $cat_label ) : ?>
							<option value="<?php echo esc_attr( $cat_key ); ?>" <?php selected( null !== $editing_vendor ? (string) $editing_vendor['category'] : '', $cat_key ); ?>><?php echo esc_html( $cat_label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th><label for="ua_pattern"><?php esc_html_e( 'User-Agent contains', 'vcns-security-automation-manager' ); ?></label></th>
					<td><input type="text" id="ua_pattern" name="ua_pattern" placeholder="QualysGuard" value="<?php echo esc_attr( null !== $editing_vendor ? (string) $editing_vendor['ua_pattern'] : '' ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="verification_method"><?php esc_html_e( 'Verification method', 'vcns-security-automation-manager' ); ?></label></th>
					<td>
						<?php $editing_verification_method = null !== $editing_vendor ? (string) $editing_vendor['verification_method'] : ''; ?>
						<select id="verification_method" name="verification_method">
							<option value="none" <?php selected( $editing_verification_method, 'none' ); ?>><?php esc_html_e( 'None', 'vcns-security-automation-manager' ); ?></option>
							<option value="cidr" <?php selected( $editing_verification_method, 'cidr' ); ?>><?php esc_html_e( 'Published CIDR ranges', 'vcns-security-automation-manager' ); ?></option>
							<option value="fcrdns" <?php selected( $editing_verification_method, 'fcrdns' ); ?>><?php esc_html_e( 'Forward-confirmed reverse DNS', 'vcns-security-automation-manager' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th><label for="cidr_ranges"><?php esc_html_e( 'CIDR ranges (one per line)', 'vcns-security-automation-manager' ); ?></label></th>
					<td><textarea id="cidr_ranges" name="cidr_ranges" rows="3" style="width:100%;max-width:400px" placeholder="64.39.96.0/20"><?php echo esc_textarea( null !== $editing_vendor ? implode( "\n", (array) $editing_vendor['cidr_ranges'] ) : '' ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="rdns_suffixes"><?php esc_html_e( 'rDNS hostname suffixes (one per line)', 'vcns-security-automation-manager' ); ?></label></th>
					<td><textarea id="rdns_suffixes" name="rdns_suffixes" rows="3" style="width:100%;max-width:400px" placeholder="qualys.com"><?php echo esc_textarea( null !== $editing_vendor ? implode( "\n", (array) $editing_vendor['rdns_suffixes'] ) : '' ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="source_url"><?php esc_html_e( 'Source URL', 'vcns-security-automation-manager' ); ?></label></th>
					<td><input type="url" id="source_url" name="source_url" required style="width:100%;max-width:400px" placeholder="https://..." value="<?php echo esc_attr( null !== $editing_vendor ? (string) $editing_vendor['source_url'] : '' ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="notes"><?php esc_html_e( 'Notes', 'vcns-security-automation-manager' ); ?></label></th>
					<td><textarea id="notes" name="notes" rows="2" style="width:100%;max-width:400px"><?php echo esc_textarea( null !== $editing_vendor ? (string) $editing_vendor['notes'] : '' ); ?></textarea></td>
				</tr>
			</table>
			<?php submit_button( null !== $editing_vendor ? __( 'Save changes', 'vcns-security-automation-manager' ) : __( 'Add vendor', 'vcns-security-automation-manager' ), 'primary', 'submit', false ); ?>
			<?php if ( null !== $editing_vendor ) : ?>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'vendors', $base_url ) ); ?>" class="button"><?php esc_html_e( 'Cancel', 'vcns-security-automation-manager' ); ?></a>
			<?php endif; ?>
		</form>

	<?php endif; ?>
</div>
