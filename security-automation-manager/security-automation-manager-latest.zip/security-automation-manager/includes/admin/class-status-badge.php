<?php
/**
 * Renders the small coloured status badge used by the Settings → All
 * tab's Layer 4/Layer 5 pillar rows -- modeled directly on Risk_Badge
 * (same forgiving-unrecognised-input contract, same .wp-sam-meta-popover
 * hover/focus tooltip mechanism).
 *
 * This is a display-layer vocabulary for the cross-pillar Settings table
 * only. It does not rename or replace CSP's own mode terminology
 * (csp_policy_profiles.mode, its 'enforce' CSS class, or its dedicated
 * Profiles-tab UI) -- those stay exactly as they are, since "Enforce" is
 * precise, pillar-specific terminology technical users still need there.
 */

declare( strict_types=1 );

namespace WP_SAM\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Status_Badge {

	public const STATE_NOT_CONFIGURED = 'not-configured';
	public const STATE_DISABLED       = 'disabled';
	public const STATE_REPORT_ONLY    = 'report-only';
	public const STATE_ACTIVE         = 'active';

	/**
	 * @param string $state One of the STATE_* constants (an unrecognised
	 *                      state still renders, with a neutral style,
	 *                      rather than being rejected).
	 * @param string $label Visible text, e.g. "Frontend: Active".
	 * @param string $note  Optional hover/focus popover explanation. Empty
	 *                      renders a plain, non-interactive badge.
	 * @return string Pre-escaped HTML.
	 */
	public static function render( string $state, string $label, string $note = '' ): string {
		$state = '' !== $state ? $state : self::STATE_NOT_CONFIGURED;
		$note  = trim( $note );
		$class = 'wp-sam-status-badge status-' . $state;

		if ( '' === $note ) {
			return '<span class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</span>';
		}

		return '<span class="' . esc_attr( $class . ' wp-sam-status-badge--has-note' ) . '" tabindex="0">'
			. esc_html( $label )
			. '<span class="wp-sam-meta-popover" role="tooltip">' . esc_html( $note ) . '</span>'
			. '</span>';
	}

	/**
	 * CSP-only: renders a per-surface automation-mode badge. $label comes
	 * verbatim from Automation_Config::mode_label() / Automation_Mode_Registry
	 * -- no mode identifier or label text is redefined here.
	 */
	public static function render_automation( string $label ): string {
		return '<span class="wp-sam-status-badge wp-sam-status-badge--automation">' . esc_html( $label ) . '</span>';
	}

	/**
	 * Pass/warning/fail/info outcome badge -- promoted out of what used to
	 * be an inline closure duplicated across page-overview.php's Readiness
	 * and Security Health tabs (`.wp-sam-readiness-badge`, styled in
	 * assets/css/admin.css). A third consumer, the Recommendations tab
	 * (Phase 4F), is why this became a shared method instead of a third
	 * copy of the same lookup.
	 *
	 * @param string      $status One of pass|warning|fail|info (an
	 *                            unrecognised value still renders, labelled
	 *                            "Unknown", matching the prior closure's
	 *                            own forgiving behaviour).
	 * @param string|null $label  Visible text. Null uses the built-in
	 *                            Pass/Warning/Fail/Info label for $status --
	 *                            what every existing Readiness/Security
	 *                            Health call site wants. Pass an explicit
	 *                            label when the badge needs to say
	 *                            something more specific, e.g. a risk level
	 *                            ("Critical risk") mapped onto one of these
	 *                            four styles.
	 * @return string Pre-escaped HTML.
	 */
	public static function render_outcome( string $status, ?string $label = null ): string {
		if ( null === $label ) {
			$labels = array(
				'pass'    => __( 'Pass', 'vcns-security-automation-manager' ),
				'warning' => __( 'Warning', 'vcns-security-automation-manager' ),
				'fail'    => __( 'Fail', 'vcns-security-automation-manager' ),
				'info'    => __( 'Info', 'vcns-security-automation-manager' ),
			);
			$label  = $labels[ $status ] ?? __( 'Unknown', 'vcns-security-automation-manager' );
		}

		return '<span class="wp-sam-readiness-badge status-' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
	}

	/**
	 * Renders one of the Customer-Centred Administration Experience's fixed
	 * outcome states (Protected/Learning/Monitoring/Needs attention/Not in
	 * use/Unavailable -- see WP_SAM\Admin\Protection_Status). Per spec §10.1,
	 * "The UI shall not use colour alone to communicate state": every state
	 * pairs a decorative, aria-hidden dashicon with a visible text label, so
	 * the label -- not the icon or the colour -- carries the accessible name.
	 *
	 * @param string $state One of Protection_Status::STATE_* (an unrecognised
	 *                      value still renders, with a neutral style).
	 * @return string Pre-escaped HTML.
	 */
	public static function render_protection_state( string $state ): string {
		$labels = array(
			'protected'       => __( 'Protected', 'vcns-security-automation-manager' ),
			'learning'        => __( 'Learning', 'vcns-security-automation-manager' ),
			'monitoring'      => __( 'Monitoring', 'vcns-security-automation-manager' ),
			'needs_attention' => __( 'Needs attention', 'vcns-security-automation-manager' ),
			'not_in_use'      => __( 'Not in use', 'vcns-security-automation-manager' ),
			'unavailable'     => __( 'Unavailable', 'vcns-security-automation-manager' ),
		);
		$icons  = array(
			'protected'       => 'dashicons-yes-alt',
			'learning'        => 'dashicons-book-alt',
			'monitoring'      => 'dashicons-visibility',
			'needs_attention' => 'dashicons-warning',
			'not_in_use'      => 'dashicons-minus',
			'unavailable'     => 'dashicons-editor-help',
		);

		$label = $labels[ $state ] ?? __( 'Unknown', 'vcns-security-automation-manager' );
		$icon  = $icons[ $state ] ?? 'dashicons-editor-help';

		return '<span class="wp-sam-protection-badge protection-state-' . esc_attr( $state ) . '">'
			. '<span class="dashicons ' . esc_attr( $icon ) . '" aria-hidden="true"></span>'
			. '<span class="wp-sam-protection-badge-label">' . esc_html( $label ) . '</span>'
			. '</span>';
	}
}
