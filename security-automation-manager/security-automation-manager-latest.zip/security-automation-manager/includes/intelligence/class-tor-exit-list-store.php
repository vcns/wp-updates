<?php
/**
 * CRUD and refresh for sam_tor_exit_nodes: the Tor Project's own public
 * bulk exit-node list (Phase 4A, .roadmap/phase4_plan.md -- Tor Awareness,
 * .roadmap/phase3_early_plan.md §13.6).
 *
 * Deliberately built first among Geo-IP/ASN/Tor: the Tor Project publishes
 * this list at a fixed, free, unauthenticated URL -- no account, API key,
 * or licensing decision required, unlike Geo-IP (needs a chosen provider
 * and the customer's own credentials) or ASN (needs a chosen lookup
 * mechanism). See .roadmap/phase4_plan.md Phase 4A.
 *
 * refresh() replaces the table wholesale on a successful fetch (delete-all
 * then bulk-insert) rather than diffing -- the list has no per-entry
 * history worth keeping, and yesterday's node that's no longer an exit
 * relay today is just noise, not something to track drift on. A fetch
 * failure, or a suspiciously small result (a real Tor network reliably has
 * over a thousand exit relays; a mangled or truncated fetch would return
 * far fewer), leaves the existing table completely untouched -- matching
 * this build's established "a refresh failure never revokes known-good
 * data" pattern (see Intelligence\Rollback_Guard's docblock,
 * docs/remote-config-and-signing.md's failure-scenario guidance).
 */

declare( strict_types=1 );

namespace WP_SAM\Intelligence;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Tor_Exit_List_Store {

	private const LIST_URL = 'https://check.torproject.org/torbulkexitlist';

	/**
	 * Below this count, a "successful" fetch is treated as suspect (likely
	 * truncated, a maintenance page, or an unexpected response format) and
	 * rejected rather than replacing known-good data with it.
	 */
	private const MIN_PLAUSIBLE_COUNT = 100;

	/**
	 * Checks whether an IP address is a known Tor exit node.
	 *
	 * @param string $ip IP address.
	 * @return bool True when it is a known exit node.
	 */
	public function is_exit_node( string $ip ): bool {
		if ( '' === $ip ) {
			return false;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'sam_tor_exit_nodes';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT 1 FROM {$table} WHERE ip = %s LIMIT 1",
				$ip
			)
		);

		return null !== $found;
	}

	/**
	 * Counts the stored exit nodes.
	 *
	 * @return int Number of nodes.
	 */
	public function count(): int {
		global $wpdb;
		$table = $wpdb->prefix . 'sam_tor_exit_nodes';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
	}

	/**
	 * Returns when the exit list was last refreshed successfully.
	 *
	 * @return string|null Time of the last refresh, or null when it has not been refreshed.
	 */
	public function last_refreshed_at(): ?string {
		$value = get_option( 'wp_sam_tor_list_refreshed_at', '' );
		return '' !== $value ? (string) $value : null;
	}

	/**
	 * Returns the outcome of the last exit list fetch.
	 *
	 * @return string Status code, or an empty string when none has run.
	 */
	public function last_fetch_status(): string {
		return (string) get_option( 'wp_sam_tor_list_last_fetch_status', '' );
	}

	/**
	 * Fetches the current bulk exit list and replaces the stored set on
	 * success. Never touches the existing table on failure.
	 *
	 * @return array{status:string, count:int, message:string}
	 */
	public function refresh(): array {
		$response = wp_remote_get(
			self::LIST_URL,
			array(
				'timeout'    => 15,
				'sslverify'  => true,
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; VCNS-Security-Automation-Manager/' . WP_SAM_VERSION . '; ' . get_bloginfo( 'url' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $this->record_failure(
				sprintf(
					/* translators: %s: error message returned by the HTTP request */
					__( 'Fetch failed: %s', 'vcns-security-automation-manager' ),
					$response->get_error_message()
				)
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return $this->record_failure(
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Fetch returned HTTP %d.', 'vcns-security-automation-manager' ),
					$code
				)
			);
		}

		$body = wp_remote_retrieve_body( $response );
		$ips  = $this->parse( $body );

		if ( count( $ips ) < self::MIN_PLAUSIBLE_COUNT ) {
			return $this->record_failure(
				sprintf(
					/* translators: %d: number of plausible Tor exit-node entries found */
					__( 'Fetch returned only %d plausible entries -- rejected as likely truncated or malformed.', 'vcns-security-automation-manager' ),
					count( $ips )
				)
			);
		}

		$this->replace_all( $ips );

		$now = current_time( 'mysql', true );
		update_option( 'wp_sam_tor_list_refreshed_at', $now );
		update_option( 'wp_sam_tor_list_last_fetch_status', 'success' );

		return array(
			'status'  => 'refreshed',
			'count'   => count( $ips ),
			'message' => sprintf(
				/* translators: %d: number of records/rules/fields/nodes parsed */
				__( 'Refreshed %d exit node(s).', 'vcns-security-automation-manager' ),
				count( $ips )
			),
		);
	}

	/** @return array<int, string> */
	private function parse( string $body ): array {
		$lines = preg_split( '/\r\n|\r|\n/', trim( $body ) );
		if ( false === $lines ) {
			return array();
		}

		$ips = array();
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line || str_starts_with( $line, '#' ) ) {
				continue;
			}
			if ( false !== filter_var( $line, FILTER_VALIDATE_IP ) ) {
				$ips[] = $line;
			}
		}

		return array_values( array_unique( $ips ) );
	}

	/** @param array<int, string> $ips */
	private function replace_all( array $ips ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'sam_tor_exit_nodes';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "TRUNCATE TABLE {$table}" );

		// Chunked multi-row insert -- a single query per ~500 rows rather
		// than one query per IP, since the list runs to well over a
		// thousand entries.
		foreach ( array_chunk( $ips, 500 ) as $chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $chunk ), '(%s)' ) );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query(
				$wpdb->prepare(
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- $placeholders is a dynamically-built run of literal (%s) groups, one per row in $chunk; the sniff can't see the placeholder count matches count($chunk) at analysis time.
					"INSERT INTO {$table} (ip) VALUES {$placeholders}",
					...$chunk
				)
			);
		}
	}

	/** @return array{status:string, count:int, message:string} */
	private function record_failure( string $message ): array {
		update_option( 'wp_sam_tor_list_last_fetch_status', 'failed' );

		return array(
			'status'  => 'failed',
			'count'   => $this->count(),
			'message' => $message,
		);
	}
}
