<?php
/**
 * Storage for request-observation events (Request Observation Framework,
 * Layer 3: Continuous Intelligence).
 *
 * Modeled directly on Pillar_Violation_Store: named columns for what's
 * genuinely filterable/sortable (surface, detector_id, detector_family,
 * severity, confidence), a `detail` JSON blob for everything else (IP,
 * user agent, method, path, and any detector-specific evidence) since no
 * detector family exists yet to fix its evidence shape. True upsert on a
 * stable fingerprint, with the same hourly rate-limit guard
 * Pillar_Violation_Store already uses, so a single noisy detector/surface
 * pair can't flood the table.
 *
 * Writes directly to its own table rather than going through Audit_Log --
 * Audit_Log is shaped for low-frequency discrete lifecycle events (it
 * double-writes an admin-notices option and error_log() on every call),
 * wrong for something that can fire on every request.
 *
 * The fingerprint is detector_id+surface+ip only, not the specific rule
 * that matched -- a single detector can carry several rules of differing
 * severity (see Detectors\Pattern_Detector), so a second, later request
 * from the same source matching a DIFFERENT rule under the same detector
 * upserts into the same row rather than creating a new one. The upsert
 * therefore refreshes severity/confidence together with detail/
 * last_seen_at on every occurrence, not just detail -- otherwise a row's
 * own detail (naming the latest matched rule) could disagree with its
 * severity/confidence columns (still reflecting whichever rule matched
 * first). occurrence_count and first_seen_at are the only fields that
 * stay anchored to history; everything else reflects the most recent hit.
 *
 * Schema v30 (Phase 3J) adds a real, indexed `ip` column alongside the
 * `detail` blob's own copy of it -- distinct_ips()/active_detector_
 * surfaces() below back Campaign_Detector's correlation query, which needs
 * to count distinct sources cheaply and can't scan JSON to do it.
 */

declare( strict_types=1 );

namespace WP_SAM\Intelligence;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Event_Store {

	private const MAX_PER_HOUR_PER_DETECTOR_SURFACE = 500;
	private const RATE_LIMIT_WINDOW                 = HOUR_IN_SECONDS;
	private const MAX_DETAIL_BYTES                  = 8192;

	private const SEVERITIES = array( 'low', 'medium', 'high', 'critical', 'unknown' );

	/**
	 * @param array<string,mixed> $detail Evidence fields (ip, user agent, method, path, and any
	 *                                    detector-specific data), stored as-is (size-capped) in the
	 *                                    detail JSON column.
	 */
	public function record( string $detector_id, string $detector_family, string $surface, string $severity, ?float $confidence, string $ip, array $detail ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'sam_request_events';

		$detector_id     = sanitize_text_field( substr( $detector_id, 0, 64 ) );
		$detector_family = sanitize_text_field( substr( $detector_family, 0, 64 ) );
		$surface         = in_array( $surface, array( 'frontend', 'admin', 'login', 'api' ), true ) ? $surface : 'frontend';
		$severity        = in_array( $severity, self::SEVERITIES, true ) ? $severity : 'unknown';

		if ( '' === $detector_id || '' === $detector_family ) {
			return;
		}

		$rate_key = 'wp_sam_request_event_rate_' . $detector_id . '_' . $surface;
		$count    = (int) get_transient( $rate_key );
		if ( $count >= self::MAX_PER_HOUR_PER_DETECTOR_SURFACE ) {
			return;
		}
		set_transient( $rate_key, $count + 1, self::RATE_LIMIT_WINDOW );

		$detail_json = wp_json_encode( $detail );
		if ( false === $detail_json ) {
			$detail_json = '{}';
		}
		if ( strlen( $detail_json ) > self::MAX_DETAIL_BYTES ) {
			$detail_json = substr( $detail_json, 0, self::MAX_DETAIL_BYTES );
		}

		$confidence_arg = null !== $confidence ? sprintf( '%.4f', $confidence ) : '';
		$fingerprint    = hash( 'sha256', $detector_id . '|' . $surface . '|' . $ip );
		$now            = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"INSERT INTO {$table} (
					surface, detector_id, detector_family, severity, confidence, ip, detail,
					fingerprint, occurrence_count, first_seen_at, last_seen_at
				) VALUES (
					%s, %s, %s, %s, NULLIF(%s, ''), %s, %s,
					%s, %d, %s, %s
				) ON DUPLICATE KEY UPDATE
					occurrence_count = occurrence_count + 1,
					last_seen_at = VALUES(last_seen_at),
					severity = VALUES(severity),
					confidence = VALUES(confidence),
					detail = VALUES(detail)",
				$surface,
				$detector_id,
				$detector_family,
				$severity,
				$confidence_arg,
				substr( $ip, 0, 64 ),
				$detail_json,
				$fingerprint,
				1,
				$now,
				$now
			)
		);
	}

	/**
	 * Distinct, non-empty source IPs that have hit this detector+surface
	 * within the last $since_hours -- the core signal Campaign_Detector
	 * correlates on (.roadmap/phase3_early_plan.md §14).
	 *
	 * @return array<int, string>
	 */
	public function distinct_ips( string $detector_id, string $surface, int $since_hours ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'sam_request_events';
		$since = gmdate( 'Y-m-d H:i:s', time() - ( max( 1, $since_hours ) * HOUR_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_col(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT DISTINCT ip FROM {$table} WHERE detector_id = %s AND surface = %s AND ip != '' AND last_seen_at >= %s",
				$detector_id,
				$surface,
				$since
			)
		);

		return ! empty( $rows ) ? $rows : array();
	}

	/**
	 * Every distinct (detector_id, detector_family, surface) combination with
	 * at least one event in the last $since_hours -- what Campaign_Detector
	 * iterates instead of guessing which detectors are even active.
	 *
	 * @return array<int, array{detector_id:string, detector_family:string, surface:string}>
	 */
	public function active_detector_surfaces( int $since_hours ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'sam_request_events';
		$since = gmdate( 'Y-m-d H:i:s', time() - ( max( 1, $since_hours ) * HOUR_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT DISTINCT detector_id, detector_family, surface FROM {$table} WHERE last_seen_at >= %s",
				$since
			),
			ARRAY_A
		);

		return ! empty( $rows ) ? $rows : array();
	}

	/**
	 * Total occurrences recorded for $detector_id (any surface, any source)
	 * among rows with activity in the last $since_hours -- used by
	 * Recommendation_Rule_Detector_Disabled_But_Firing (Phase 4F) to judge
	 * whether a disabled detector had real matches recently.
	 *
	 * Sums each qualifying row's own occurrence_count rather than counting
	 * rows: a single noisy source upserts into one row, and that row's
	 * occurrence_count is exactly "how many times this detector+surface+
	 * source combination has matched," so summing across the (typically
	 * few) rows active in the window is a truthful activity total, not a
	 * row-count-as-proxy. occurrence_count is lifetime-cumulative per row,
	 * not itself windowed, so a row last touched years ago but still within
	 * $since_hours would contribute its full historical count -- the same
	 * known, accepted staleness-at-the-edges tradeoff distinct_ips()/
	 * active_detector_surfaces() above already carry, not a new compromise
	 * introduced here.
	 */
	public function occurrences_since( string $detector_id, int $since_hours ): int {
		global $wpdb;
		$table = $wpdb->prefix . 'sam_request_events';
		$since = gmdate( 'Y-m-d H:i:s', time() - ( max( 1, $since_hours ) * HOUR_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT COALESCE(SUM(occurrence_count), 0) FROM {$table} WHERE detector_id = %s AND last_seen_at >= %s",
				$detector_id,
				$since
			)
		);
	}

	/**
	 * Total detections across every detector/surface/source active in the
	 * last $since_hours -- backs the Customer-Centred Administration
	 * Experience's Recent Activity strip (spec §9). Deliberately labelled
	 * "detections," not "requests," on that strip: this sums each
	 * qualifying row's occurrence_count exactly like occurrences_since()
	 * does (same lifetime-cumulative-per-row caveat documented there), and
	 * a single underlying request that matches more than one detector
	 * family upserts into more than one row (fingerprint is detector_id +
	 * surface + ip) -- so this total can legitimately exceed the number of
	 * requests that actually occurred. Spec §9.1 requires exactly this
	 * distinction: "A single request detected by multiple detector
	 * families must not be presented as multiple suspicious requests unless
	 * the label explicitly says 'detections'."
	 */
	public function total_occurrences_since( int $since_hours ): int {
		global $wpdb;
		$table = $wpdb->prefix . 'sam_request_events';
		$since = gmdate( 'Y-m-d H:i:s', time() - ( max( 1, $since_hours ) * HOUR_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				"SELECT COALESCE(SUM(occurrence_count), 0) FROM {$table} WHERE last_seen_at >= %s",
				$since
			)
		);
	}
}
