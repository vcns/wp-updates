<?php
/**
 * Caches this site's own /humans.txt content (Phase 4C extension, user-
 * requested -- see Robots_Rules_Store's own docblock for the shared fetch/
 * cache reasoning).
 *
 * humans.txt is an informal credits/colophon convention with no directive
 * syntax at all -- there is nothing here to parse into a rule, so there is
 * no compliance detector alongside Humans_Txt_Detector's plain "was this
 * examined" visit signal. This store exists only to give an administrator
 * the same presence/last-fetch visibility Robots.txt Rules already gives,
 * for consistency across every well-known file this plugin tracks.
 */

declare( strict_types=1 );

namespace WP_SAM\Intelligence;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Humans_Txt_Store {

	/** @var callable(string):(array|\WP_Error) Same_Host_Fetcher (wp_remote_get() that never follows a redirect off this site) by default; injectable so tests never make a real HTTP call. */
	private $http_get;

	/**
	 * Constructor.
	 *
	 * @param callable|null $http_get HTTP GET function, defaults to wp_remote_get().
	 */
	public function __construct( ?callable $http_get = null ) {
		$this->http_get = $http_get ?? static fn ( string $url ) => ( new Same_Host_Fetcher() )->get(
			$url,
			array(
				'timeout'    => 10,
				'sslverify'  => true,
				'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; VCNS-Security-Automation-Manager/' . WP_SAM_VERSION . '; ' . get_bloginfo( 'url' ),
			)
		);
	}

	/**
	 * True once a fetch has ever succeeded -- deliberately NOT "is content()
	 * non-empty": a 0-byte or whitespace-only humans.txt is a legitimate,
	 * successfully-fetched file, and reporting it as "not present" would be
	 * indistinguishable from the file never having been fetched at all.
	 */
	public function is_present(): bool {
		return 'success' === $this->last_fetch_status();
	}

	/**
	 * Returns the cached humans.txt content.
	 *
	 * @return string Content, or an empty string.
	 */
	public function content(): string {
		return (string) get_option( 'wp_sam_humans_txt_content', '' );
	}

	/**
	 * Returns when humans.txt was last refreshed successfully.
	 *
	 * @return string|null Time of the last refresh, or null when it has not been refreshed.
	 */
	public function last_refreshed_at(): ?string {
		$value = get_option( 'wp_sam_humans_txt_refreshed_at', '' );
		return '' !== $value ? (string) $value : null;
	}

	/**
	 * Returns the outcome of the last humans.txt fetch.
	 *
	 * @return string Status code, or an empty string when none has run.
	 */
	public function last_fetch_status(): string {
		return (string) get_option( 'wp_sam_humans_txt_last_fetch_status', '' );
	}

	/**
	 * Fetches this site's own /humans.txt and replaces the cached content
	 * on success, or clears it when the site has no such file (HTTP 404/
	 * 410 -- an answer, not a failure). Never touches cached content on
	 * failure.
	 *
	 * @return array{status:string, count:int, message:string}
	 */
	public function refresh(): array {
		$response = ( $this->http_get )( home_url( '/humans.txt' ) );

		if ( is_wp_error( $response ) ) {
			return $this->record_failure(
				sprintf(
					/* translators: %s: error message returned by the HTTP request */
					__( 'Fetch failed: %s', 'vcns-security-automation-manager' ),
					$response->get_error_message()
				)
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 404 === $code || 410 === $code ) {
			return $this->record_absent( $code );
		}
		if ( 200 !== $code ) {
			return $this->record_failure(
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Fetch returned HTTP %d.', 'vcns-security-automation-manager' ),
					$code
				)
			);
		}

		$content = (string) wp_remote_retrieve_body( $response );

		update_option( 'wp_sam_humans_txt_content', $content );
		update_option( 'wp_sam_humans_txt_refreshed_at', current_time( 'mysql', true ) );
		update_option( 'wp_sam_humans_txt_last_fetch_status', 'success' );

		return array(
			'status'  => 'refreshed',
			'count'   => strlen( $content ),
			'message' => __( 'Refreshed humans.txt.', 'vcns-security-automation-manager' ),
		);
	}

	/** @return array{status:string, count:int, message:string} */
	private function record_absent( int $code ): array {
		delete_option( 'wp_sam_humans_txt_content' );
		update_option( 'wp_sam_humans_txt_refreshed_at', current_time( 'mysql', true ) );
		update_option( 'wp_sam_humans_txt_last_fetch_status', 'absent' );

		return array(
			'status'  => 'absent',
			'count'   => 0,
			'message' => "No /humans.txt on this site (HTTP {$code}).",
		);
	}

	/** @return array{status:string, count:int, message:string} */
	private function record_failure( string $message ): array {
		update_option( 'wp_sam_humans_txt_last_fetch_status', 'failed' );

		return array(
			'status'  => 'failed',
			'count'   => strlen( $this->content() ),
			'message' => $message,
		);
	}
}
